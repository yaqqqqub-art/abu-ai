"""
Abu Robot - Remote Control Server (PC side) - v2
----------------------------------------------------
Run this ON YOUR PC. Up to THREE phones can connect at the same time
(like 3 game controllers) and control this PC from their browsers.

NEW IN THIS VERSION:
  - Username + Password accounts (up to 3) - no more typing usernames into
    the terminal: the FIRST phone/browser that opens this server now gets a
    "Create Account" page automatically. After that, anyone opening the
    address sees a normal Sign In page, with a "Create Account" link still
    shown as long as fewer than 3 accounts exist.
  - The Sign In page now shows the Abu AI logo, a short feature list, and
    this computer's name + local IP (e.g. 192.168.1.23) so whoever is
    connecting can see exactly which PC they're about to control - if the
    IP genuinely can't be found, it says "IP not available" instead.
  - "Abu AI" branding/logo on the login, control, and monitor pages
  - "Full Screen" button - makes the PC screen image fill your phone screen
  - "Touchpad Mode" button (separate button) - drag your finger on the
    screen area to move the mouse like a laptop touchpad:
        1 finger drag   = move mouse
        1 finger tap    = left click
        2 finger tap    = right click
        2 finger drag   = scroll
        2 finger pinch  = zoom (Ctrl + scroll)
  - Up to 3 phones can connect as Controller 1 / 2 / 3 at the same time
  - Live activity log shows which controller pressed which button
  - "Phone" button - opens a Phone <-> PC file transfer panel:
        * Set a timer (in minutes) and press Start - transfer is only
          allowed while the timer is running; press Stop to end it early.
        * Phone -> PC: pick photos/files on your phone and upload them;
          they land in the "phone_uploads/controllerN" folder on the PC.
        * PC -> Phone: any file you drop into the "pc_shared" folder on
          the PC shows up as a downloadable link on the phone.
        * NOTE: a phone's SMS/text messages can't be read from a normal
          browser page (no browser grants that permission) - this only
          moves photos/files, not message contents.
        * "Unlimited" button - runs the file-transfer session with no
          time limit until you press Stop (instead of typing minutes).
        * Nickname + battery: type a name for the phone, and its
          battery % is auto-reported (if the browser supports it).
        * "Share My Screen" - mirrors the PHONE's screen to the PC.
          Open http://localhost:5000/monitor IN A BROWSER ON THE PC
          to see all connected phones' names/battery/live screens.
          (Screen sharing from a phone browser needs a fairly recent
          Android + Chrome; not all phones/browsers support it.)
  - "Xbox Controller Mode" toggle inside Game Controller panel - makes
    the Y/X/B/A, L1/R1 and D-pad buttons press an actual virtual Xbox
    360 controller on the PC (so real games that need a gamepad, not
    just a keyboard, work). Needs the optional vgamepad package AND
    the ViGEmBus driver installed on the PC (Windows only) - without
    them, those buttons just fall back to keyboard presses as before.

SECURITY NOTE:
  - Only works while phone and PC are on the SAME Wi-Fi network
  - Anyone with a valid username/password on your network can control this PC
  - Not meant to be exposed to the open internet as-is

Requirements (install first):
    pip install flask mss pillow pyautogui
    pip install vgamepad   (OPTIONAL, Windows only, for "Xbox Controller Mode" -
                             also needs the ViGEmBus driver:
                             https://github.com/ViGEm/ViGEmBus/releases)

How to run:
    python abu_robot_server.py
    (first time only: it will ask you to create a Username + Password
    in the terminal - up to 3 accounts, one per phone/family member)

Then on your PC, find your PC's local IP:
    Windows:   ipconfig            (look for "IPv4 Address")
    Mac/Linux: ifconfig  or  ip addr

On each phone (same Wi-Fi), open a browser and go to:
    http://<your-pc-ip>:5000
"""

from flask import Flask, Response, request, session, redirect, url_for, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import mss
import io
import os
import sys
import json
import socket
import platform
import subprocess
import shlex
import time
import threading
import secrets
import datetime
from collections import deque
from PIL import Image
import pyautogui

# Optional: real Xbox-controller emulation (Windows only).
# pip install vgamepad, plus the ViGEmBus driver:
#   https://github.com/ViGEm/ViGEmBus/releases
# If this isn't installed, the Game Controller buttons still work as
# keyboard presses - they just won't show up as a real Xbox gamepad.
try:
    import vgamepad as vg
    vg.VX360Gamepad()  # quick check the ViGEmBus driver is actually installed
    XBOX_AVAILABLE = True
except Exception:
    vg = None
    XBOX_AVAILABLE = False

# ---------------------------------------------------------
# SETTINGS
# ---------------------------------------------------------
PORT = 5000
JPEG_QUALITY = 45
MAX_WIDTH = 1000
FRAME_DELAY = 0.12
MAX_CONTROLLERS = 3
CONTROLLER_TIMEOUT = 15   # seconds of no heartbeat before a slot is freed
MOUSE_SENSITIVITY = 2.2

# ---- Phone <-> PC file transfer settings ----
# When bundled into an .exe with PyInstaller, __file__ points at a disposable
# temp extraction folder - use the folder the .exe itself lives in instead,
# so saved apps/users/uploaded files persist between runs.
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Photos/files you send FROM your phone land here, sorted by controller slot
PHONE_UPLOAD_DIR = os.path.join(BASE_DIR, "phone_uploads")
# Put files here on the PC that you want to be able to pull down TO your phone
PC_SHARE_DIR = os.path.join(BASE_DIR, "pc_shared")
os.makedirs(PHONE_UPLOAD_DIR, exist_ok=True)
os.makedirs(PC_SHARE_DIR, exist_ok=True)
PHONE_SESSION_MAX_MINUTES = 240   # safety cap so a timed (non-unlimited) session can't run forever
PHONE_SCREEN_STALE_SECONDS = 8    # if no new mirrored frame in this long, treat it as "not sharing"

# ---- Direct-touch mode needs the real PC screen size once, up front ----
with mss.mss() as _sct:
    _mon = _sct.monitors[1]
    SCREEN_W, SCREEN_H = _mon["width"], _mon["height"]

# ---- PC app launcher (tap an app in the "Apps" panel to open it on the PC) ----
APPS_FILE = os.path.join(BASE_DIR, "abu_apps.json")


def default_apps():
    system = platform.system()
    if system == "Windows":
        return [
            {"name": "Chrome", "path": "chrome"},
            {"name": "Edge", "path": "msedge"},
            {"name": "Notepad", "path": "notepad"},
            {"name": "Calculator", "path": "calc"},
            {"name": "File Explorer", "path": "explorer"},
            {"name": "Paint", "path": "mspaint"},
            {"name": "WordPad", "path": "write"},
            {"name": "Task Manager", "path": "taskmgr"},
            {"name": "Control Panel", "path": "control"},
            {"name": "Settings", "path": "start ms-settings:"},
            {"name": "Command Prompt", "path": "cmd"},
            {"name": "Snipping Tool", "path": "SnippingTool"},
        ]
    elif system == "Darwin":
        return [
            {"name": "Safari", "path": "open -a Safari"},
            {"name": "Notes", "path": "open -a Notes"},
            {"name": "Calculator", "path": "open -a Calculator"},
            {"name": "Finder", "path": "open -a Finder"},
            {"name": "Preview", "path": "open -a Preview"},
            {"name": "System Settings", "path": "open -a 'System Settings'"},
            {"name": "Terminal", "path": "open -a Terminal"},
        ]
    else:
        return [
            {"name": "Files", "path": "xdg-open ."},
        ]


def save_apps(apps):
    try:
        with open(APPS_FILE, "w", encoding="utf-8") as f:
            json.dump(apps, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def load_apps():
    if os.path.exists(APPS_FILE):
        try:
            with open(APPS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    apps = default_apps()
    save_apps(apps)
    return apps


apps_list = load_apps()

# ---- Abu AI logo (simple original badge, used on login/control/monitor pages) ----
LOGO_SVG = ('<svg class="logo" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">'
            '<circle cx="32" cy="32" r="29" fill="#132a17" stroke="#4CAF50" stroke-width="3"/>'
            '<text x="32" y="41" font-family="Arial, sans-serif" font-size="26" font-weight="bold" '
            'fill="#4CAF50" text-anchor="middle">A</text>'
            '<circle cx="32" cy="13" r="3" fill="#4CAF50"/>'
            '<line x1="32" y1="16" x2="32" y2="21" stroke="#4CAF50" stroke-width="2"/>'
            '</svg>')

# ---- This computer's name + local IP, shown on the login/control pages so
#      whoever is connecting can see exactly which PC they're about to
#      control (and to catch it if this PC isn't reachable on the network) ----
PC_NAME = platform.node() or "This PC"


def get_local_ip():
    """Best-effort local network IP (e.g. 192.168.1.23). Doesn't need real
    internet access - the UDP 'connect' below never actually sends anything,
    it just asks the OS which network interface/IP would be used."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return None
    finally:
        s.close()


PC_LOCAL_IP = get_local_ip()  # None if it genuinely couldn't be determined

# ---- Users (username + password, replaces the old single shared PIN) ----
USERS_FILE = os.path.join(BASE_DIR, "abu_users.json")


def load_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []


def save_users(users):
    try:
        with open(USERS_FILE, "w", encoding="utf-8") as f:
            json.dump(users, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


users_list = load_users()
# NOTE: accounts are no longer created by typing into the terminal - the
# first phone/browser that opens this server now gets a "Create Account"
# page automatically (see /signup below). Up to MAX_CONTROLLERS accounts
# (3) can exist at once, saved in abu_users.json.
if not users_list:
    print("এখনো কোনো Abu AI অ্যাকাউন্ট নেই।")
    print(f"ফোন/ব্রাউজারে http://<এই-PC-এর-IP>:{PORT} খুললেই প্রথম অ্যাকাউন্ট তৈরি করার ফর্ম আসবে।")

# Maps the fixed on-screen button labels (Y/X/B/A, L1/R1, dpad) to real
# Xbox-controller buttons, used only when "Xbox Controller Mode" is on.
XBOX_BUTTON_MAP = {
    'A': 'XUSB_GAMEPAD_A', 'B': 'XUSB_GAMEPAD_B',
    'X': 'XUSB_GAMEPAD_X', 'Y': 'XUSB_GAMEPAD_Y',
    'LB': 'XUSB_GAMEPAD_LEFT_SHOULDER', 'RB': 'XUSB_GAMEPAD_RIGHT_SHOULDER',
    'UP': 'XUSB_GAMEPAD_DPAD_UP', 'DOWN': 'XUSB_GAMEPAD_DPAD_DOWN',
    'LEFT': 'XUSB_GAMEPAD_DPAD_LEFT', 'RIGHT': 'XUSB_GAMEPAD_DPAD_RIGHT',
}

# Each controller slot gets its own key mapping so 3 phones can play a
# local multiplayer game on the same PC keyboard without pressing the
# same keys as each other.
KEY_MAPS = {
    1: {"up": "w", "down": "s", "left": "a", "right": "d",
        "btn1": "space", "btn2": "shiftleft", "btn3": "e", "btn4": "q"},
    2: {"up": "up", "down": "down", "left": "left", "right": "right",
        "btn1": "enter", "btn2": "shiftright", "btn3": ".", "btn4": ","},
    3: {"up": "i", "down": "k", "left": "j", "right": "l",
        "btn1": "u", "btn2": "o", "btn3": "p", "btn4": "["},
}

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
app.permanent_session_lifetime = datetime.timedelta(days=14)  # used only when "Remember Me" is checked

# ---- users are set up above (abu_users.json) - no separate PIN needed anymore ----

# ---- basic brute-force protection: lock a username out for a while after
#      too many wrong passwords in a row (resets on a correct login) ----
LOGIN_FAIL_LIMIT = 5
LOGIN_LOCK_SECONDS = 60
failed_logins = {}   # username -> {"count": int, "locked_until": timestamp}

# ---- controller slot tracking ----
lock = threading.Lock()
controllers = {}   # slot_number -> {"sid": session_id, "last_seen": timestamp}
activity_log = deque(maxlen=30)

# ---- phone <-> pc transfer session tracking ----
phone_sessions = {}   # slot_number -> {"active": bool, "unlimited": bool, "expires_at": timestamp or None}

# ---- phone info (nickname/battery) and mirrored-screen frames ----
phone_info = {}     # slot_number -> {"nickname": str, "battery": float or None}
phone_screens = {}  # slot_number -> {"jpeg": bytes, "ts": timestamp}

# ---- one virtual Xbox 360 controller per slot (only if XBOX_AVAILABLE) ----
gamepads = {}
if XBOX_AVAILABLE:
    for _s in range(1, MAX_CONTROLLERS + 1):
        try:
            gamepads[_s] = vg.VX360Gamepad()
        except Exception:
            pass


def log_action(slot, text):
    with lock:
        activity_log.appendleft(f"[Controller {slot}] {text}")


def cleanup_loop():
    while True:
        time.sleep(5)
        now = time.time()
        with lock:
            dead = [s for s, v in controllers.items() if now - v["last_seen"] > CONTROLLER_TIMEOUT]
            for s in dead:
                del controllers[s]
            for s, v in phone_sessions.items():
                if v.get("active") and not v.get("unlimited") and now >= (v.get("expires_at") or 0):
                    v["active"] = False
                    log_action(s, "phone transfer session ended (time up)")


threading.Thread(target=cleanup_loop, daemon=True).start()


# ---------------------------------------------------------
# Screen streaming (MJPEG)
# ---------------------------------------------------------
def generate_frames():
    with mss.mss() as sct:
        monitor = sct.monitors[1]
        while True:
            try:
                shot = sct.grab(monitor)
                img = Image.frombytes("RGB", shot.size, shot.rgb)
                if img.width > MAX_WIDTH:
                    ratio = MAX_WIDTH / img.width
                    img = img.resize((MAX_WIDTH, int(img.height * ratio)))
                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=JPEG_QUALITY)
                frame = buf.getvalue()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            except Exception:
                pass
            time.sleep(FRAME_DELAY)


def generate_phone_frames(slot):
    """Streams whatever frames a given phone has POSTed to /api/phone/screen_frame."""
    last_ts = 0
    while True:
        entry = phone_screens.get(slot)
        if entry and entry["ts"] != last_ts:
            last_ts = entry["ts"]
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + entry["jpeg"] + b'\r\n')
        time.sleep(0.3)


# ---------------------------------------------------------
# HTML
# ---------------------------------------------------------
LOGIN_HTML = ("""
<!DOCTYPE html>
<html><head><title>Abu AI - Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial;background:#0d0d0d;color:#eee;display:flex;justify-content:center;
     align-items:center;min-height:100vh;margin:0;padding:20px 0;box-sizing:border-box}
.box{background:#1b1b1b;padding:30px;border-radius:14px;text-align:center;width:80%;max-width:340px}
.logo{width:72px;height:72px;margin:0 auto 6px;display:block}
input{width:100%;padding:12px;font-size:18px;text-align:center;border-radius:8px;border:none;margin:8px 0;box-sizing:border-box}
button{width:100%;padding:12px;font-size:18px;border-radius:8px;border:none;background:#4CAF50;color:white;margin-top:6px}
h2{margin:6px 0 2px}
.tag{color:#888;font-size:12px;margin-bottom:14px}
.err{color:#ff6b6b}
.pcinfo{display:flex;align-items:center;justify-content:center;gap:7px;background:#141414;
        border-radius:8px;padding:8px 10px;font-size:12px;color:#bbb;margin:14px 0}
.dot{width:8px;height:8px;border-radius:50%;flex:0 0 8px}
.dot.on{background:#4CAF50}
.dot.off{background:#777}
.mono{font-family:Consolas,monospace;color:#8fd18f}
.altrow{margin-top:12px;font-size:13px}
.altrow a{color:#4CAF50;text-decoration:none;font-weight:bold}
.altrow a:hover{text-decoration:underline}
.features{text-align:left;background:#141414;border-radius:10px;padding:12px 14px;margin-top:18px;font-size:12.5px;color:#aaa}
.features h4{margin:0 0 8px;color:#8fd18f;font-size:12px;letter-spacing:.4px;text-transform:uppercase}
.features ul{margin:0;padding-left:18px}
.features li{margin:5px 0}
</style></head>
<body><div class="box">
""" + LOGO_SVG + """
<h2>Abu AI</h2>
<div class="tag">Remote Control — PC ↔ Phone</div>
{pcstatus}
<form method="POST">
<input type="text" name="username" placeholder="Username" autofocus autocapitalize="none" autocomplete="username">
<input type="password" name="password" placeholder="Password" autocomplete="current-password">
<label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#aaa;margin:6px 0 0;justify-content:center">
<input type="checkbox" name="remember" style="width:auto;margin:0" value="1"> এই ডিভাইসে মনে রাখো
</label>
<button type="submit">Connect</button>
</form>
{err}
{signup_row}
<div class="features">
<h4>এই অ্যাপে যা যা আছে</h4>
<ul>
<li>PC-এর স্ক্রিন লাইভ দেখা, মাউস/কীবোর্ড কন্ট্রোল, টাচপ্যাড মোড</li>
<li>Apps লঞ্চার — এক ট্যাপে PC-তে যেকোনো প্রোগ্রাম খোলা</li>
<li>Phone ↔ PC ফাইল/ছবি ট্রান্সফার (টাইমার সহ)</li>
<li>Game Controller / Xbox মোড</li>
<li>একসাথে সর্বোচ্চ ৩টি ফোন কানেক্ট থাকতে পারে</li>
</ul>
</div>
</div></body></html>
""")

SIGNUP_HTML = ("""
<!DOCTYPE html>
<html><head><title>Abu AI - Create Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial;background:#0d0d0d;color:#eee;display:flex;justify-content:center;
     align-items:center;min-height:100vh;margin:0;padding:20px 0;box-sizing:border-box}
.box{background:#1b1b1b;padding:30px;border-radius:14px;text-align:center;width:80%;max-width:340px}
.logo{width:72px;height:72px;margin:0 auto 6px;display:block}
input{width:100%;padding:12px;font-size:18px;text-align:center;border-radius:8px;border:none;margin:8px 0;box-sizing:border-box}
button{width:100%;padding:12px;font-size:18px;border-radius:8px;border:none;background:#4CAF50;color:white;margin-top:6px}
h2{margin:6px 0 2px}
.tag{color:#888;font-size:12px;margin-bottom:14px}
.err{color:#ff6b6b}
.ok{color:#8fd18f}
.pcinfo{display:flex;align-items:center;justify-content:center;gap:7px;background:#141414;
        border-radius:8px;padding:8px 10px;font-size:12px;color:#bbb;margin:14px 0}
.dot{width:8px;height:8px;border-radius:50%;flex:0 0 8px}
.dot.on{background:#4CAF50}
.dot.off{background:#777}
.mono{font-family:Consolas,monospace;color:#8fd18f}
.altrow{margin-top:12px;font-size:13px}
.altrow a{color:#4CAF50;text-decoration:none;font-weight:bold}
.altrow a:hover{text-decoration:underline}
.slots{font-size:11px;color:#777;margin-top:4px}
</style></head>
<body><div class="box">
""" + LOGO_SVG + """
<h2>Account তৈরি করুন</h2>
<div class="tag">প্রথমবার Abu AI ব্যবহার করছেন? এখানে সাইন আপ করুন</div>
{pcstatus}
<form method="POST">
<input type="text" name="username" placeholder="Username" autofocus autocapitalize="none" autocomplete="username">
<input type="password" name="password" placeholder="Password (কমপক্ষে ৪ অক্ষর)" autocomplete="new-password">
<input type="password" name="password2" placeholder="Password আবার লিখুন" autocomplete="new-password">
<button type="submit">Create Account</button>
</form>
{err}
<div class="slots">{slots_left} টা account slot বাকি আছে (সর্বোচ্চ 3 জন)</div>
<div class="altrow"><a href="/login">আগে থেকে account আছে? Sign In</a></div>
</div></body></html>
""")


def pc_status_html():
    if PC_LOCAL_IP:
        return ('<div class="pcinfo"><span class="dot on"></span>এই PC: <b>%s</b> — '
                '<span class="mono">%s</span></div>') % (PC_NAME, PC_LOCAL_IP)
    return ('<div class="pcinfo"><span class="dot off"></span>এই PC: <b>%s</b> — '
            'IP পাওয়া যায়নি (http not available)</div>') % (PC_NAME,)


def render_login(err=""):
    signup_row = ""
    # Only show the "Create Account" link to someone browsing from the PC
    # itself (phones on the network Sign In only - accounts are managed by
    # the PC owner, normally from the Abu AI Desktop app window).
    if len(users_list) < MAX_CONTROLLERS and is_local_request():
        signup_row = '<div class="altrow"><a href="/signup">অ্যাকাউন্ট নেই? Create Account</a></div>'
    return (LOGIN_HTML
            .replace("{pcstatus}", pc_status_html())
            .replace("{err}", err)
            .replace("{signup_row}", signup_row))


def render_signup(err=""):
    return (SIGNUP_HTML
            .replace("{pcstatus}", pc_status_html())
            .replace("{err}", err)
            .replace("{slots_left}", str(max(0, MAX_CONTROLLERS - len(users_list)))))

CONTROL_HTML = """
<!DOCTYPE html>
<html><head><title>Abu AI - Control</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial;background:#111;color:#eee;margin:0;padding:8px;text-align:center}
#screenWrap{position:relative;width:100%;max-width:100%}
img#screen{width:100%;max-width:100%;border:2px solid #444;border-radius:6px;display:block;touch-action:none}
#touchOverlay{position:absolute;top:0;left:0;width:100%;height:100%;touch-action:none;display:none}
#touchOverlay.active{display:block}
.row{display:flex;flex-wrap:wrap;justify-content:center;gap:4px;margin:6px 0}
button{padding:8px 10px;font-size:13px;border-radius:6px;border:none;background:#333;color:#eee}
button:active{background:#4CAF50}
.mod{background:#555}
.mod.active{background:#4CAF50}
.topbtn{background:#2196F3;font-weight:bold}
.topbtn.active{background:#4CAF50}
h3{margin:8px 0 4px}
input#custom{padding:8px;width:60%;border-radius:6px;border:none}
#log{background:#1a1a1a;text-align:left;font-size:12px;padding:6px;border-radius:6px;
     height:100px;overflow-y:auto;margin-top:8px}
#status{font-size:13px;color:#8fd18f}
#gamePanel{display:none;justify-content:space-between;align-items:flex-start;margin:10px 0}
#gamePanel.active{display:flex}
#dpad{display:grid;grid-template-columns:50px 50px 50px;grid-template-rows:50px 50px 50px;gap:3px}
#dpad button{font-size:18px;font-weight:bold;background:#444}
#dpad button:active{background:#4CAF50}
#shoulderRow{display:flex;justify-content:space-between;width:100%;margin-bottom:10px}
.shoulderWrap{display:flex;flex-direction:column;align-items:center}
.shoulderWrap input{width:56px;font-size:10px;text-align:center;padding:2px;border-radius:4px;border:none;margin-bottom:3px}
.shoulderWrap button{width:70px;height:34px;font-size:12px;background:#555;border-radius:8px 8px 0 0}
.shoulderWrap button:active{background:#e91e63}
#diamond{position:relative;width:160px;height:160px}
.diaBtnWrap{position:absolute;display:flex;flex-direction:column;align-items:center}
.diaBtnWrap input{width:46px;font-size:10px;text-align:center;padding:2px;border-radius:4px;border:none;margin-bottom:2px}
.diaBtnWrap button{width:46px;height:46px;border-radius:50%;font-size:13px;background:#444}
.diaBtnWrap button:active{background:#e91e63}
#dia-top{top:0;left:57px}
#dia-left{top:57px;left:0}
#dia-right{top:57px;left:114px}
#dia-bottom{top:114px;left:57px}
#phonePanel{display:none;text-align:left;background:#1a1a1a;border-radius:8px;padding:10px;margin:10px 0}
#phonePanel.active{display:block}
#phonePanel h4{margin:10px 0 4px;color:#8fd18f}
#phonePanel .timerRow{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
#phonePanel input[type=number]{width:70px;padding:8px;border-radius:6px;border:none}
#sessionState{font-weight:bold}
#sessionState.on{color:#8fd18f}
#sessionState.off{color:#ff6b6b}
#fileList{max-height:160px;overflow-y:auto;background:#111;border-radius:6px;padding:4px;margin-top:4px}
#fileList a{display:block;color:#7ec8ff;padding:4px 2px;text-decoration:none;font-size:13px;border-bottom:1px solid #222}
#fileList a:active{background:#222}
#uploadStatus{font-size:12px;color:#aaa;margin-top:4px}
.uploadStatusText{font-size:12px;color:#aaa;margin-top:4px}
.warn{font-size:12px;color:#e0c14b;margin:4px 0}
#xboxModeBtn.active{background:#ff9800}
#touchModePanel{display:none;text-align:left;background:#1a1a1a;border-radius:8px;padding:10px;margin:6px 0}
#touchModePanel.active{display:block}
#touchModePanel label{display:block;padding:6px 0}
#appsPanel{display:none;text-align:left;background:#1a1a1a;border-radius:8px;padding:10px;margin:10px 0}
#appsPanel.active{display:block}
#appsPanel h4{margin:10px 0 4px;color:#8fd18f}
.appRow{display:flex;justify-content:space-between;align-items:center;padding:6px 4px;border-bottom:1px solid #222}
.appRow button{background:#2196F3;margin-left:4px}
.appRow button.rm{background:#a33}
.headerRow{display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:4px}
.headerRow .logo{width:34px;height:34px}
</style></head>
<body>
<div class="headerRow">{logo}<h2>Abu AI</h2></div>
<div id="status">You are Controller {slot} / {max_ctrl} — connected to <b>{pcname}</b> ({pcip})</div>

<div class="row">
<button class="topbtn" id="fsBtn" onclick="toggleFullscreen()">Full Screen</button>
<button class="topbtn" id="tpBtn" onclick="toggleTouchModePanel()">Touchpad Mode</button>
<button class="topbtn" id="gcBtn" onclick="toggleGamePanel()">Game Controller</button>
<button class="topbtn" id="phoneBtn" onclick="togglePhonePanel()">Phone</button>
<button class="topbtn" id="appsBtn" onclick="toggleAppsPanel()">Apps</button>
</div>

<div id="touchModePanel">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <b>Configure Touch Input</b>
    <button onclick="closeTouchModePanel()" style="background:none;font-size:16px">&times;</button>
  </div>
  <label><input type="radio" name="touchMode" value="off" checked> Off (touch control বন্ধ)</label>
  <label><input type="radio" name="touchMode" value="trackpad"> Trackpad mode</label>
  <label><input type="radio" name="touchMode" value="direct"> Direct touch mode</label>
  <label><input type="radio" name="touchMode" value="pan2"> Touch mode with two-finger pan &amp; zoom</label>
  <label><input type="radio" name="touchMode" value="pan3"> Touch mode with three-finger pan &amp; zoom</label>
  <p class="warn" id="touchModeDesc">টাচ কন্ট্রোল এখন বন্ধ আছে।</p>
</div>

<div id="screenWrap">
<img id="screen" src="/stream">
<div id="touchOverlay"></div>
</div>

<div id="appsPanel">
  <h4>PC-র Apps (ট্যাপ করলে Open হবে)</h4>
  <div id="appsListEl" style="font-size:14px"></div>
  <h4>নতুন App যোগ করুন</h4>
  <div class="timerRow">
    <input type="text" id="newAppName" placeholder="নাম (যেমন: Chrome)" maxlength="60">
    <input type="text" id="newAppPath" placeholder="Path/Command (যেমন: chrome)" maxlength="300">
    <button onclick="addApp()">Add</button>
  </div>
  <p class="warn">Windows-এ শুধু নাম দিলেই হবে যদি সেটা PATH-এ থাকে (chrome, notepad, calc, explorer)। নাহলে পুরো path দিন, যেমন: "C:\\Program Files\\App\\app.exe"।</p>
</div>

<div id="gamePanel">
  <div style="width:100%">
    <button class="topbtn" id="xboxModeBtn" onclick="toggleXboxMode()">Xbox Controller Mode: OFF</button>
    <div id="shoulderRow"></div>
    <div style="display:flex;justify-content:space-between;width:100%;align-items:center">
      <div id="dpad">
        <div></div>
        <button id="dp-w" ontouchstart="holdStart(event,'w','UP')" ontouchend="holdEnd(event,'w','UP')" onmousedown="holdStart(event,'w','UP')" onmouseup="holdEnd(event,'w','UP')">&#9650;</button>
        <div></div>
        <button id="dp-a" ontouchstart="holdStart(event,'a','LEFT')" ontouchend="holdEnd(event,'a','LEFT')" onmousedown="holdStart(event,'a','LEFT')" onmouseup="holdEnd(event,'a','LEFT')">&#9664;</button>
        <div></div>
        <button id="dp-d" ontouchstart="holdStart(event,'d','RIGHT')" ontouchend="holdEnd(event,'d','RIGHT')" onmousedown="holdStart(event,'d','RIGHT')" onmouseup="holdEnd(event,'d','RIGHT')">&#9654;</button>
        <div></div>
        <button id="dp-s" ontouchstart="holdStart(event,'s','DOWN')" ontouchend="holdEnd(event,'s','DOWN')" onmousedown="holdStart(event,'s','DOWN')" onmouseup="holdEnd(event,'s','DOWN')">&#9660;</button>
        <div></div>
      </div>
      <div id="diamond"></div>
    </div>
  </div>
</div>

<div id="phonePanel">
  <p class="warn">নোট: ব্রাউজার থেকে ফোনের SMS/মেসেজ সরাসরি পড়া সম্ভব না (কোনো ব্রাউজার এই পারমিশন দেয় না)।
  এখানে ফোন ও পিসির মধ্যে ছবি/ফাইল আদান-প্রদান, ফোনের নাম/ব্যাটারি দেখা, এবং চাইলে ফোনের স্ক্রিন PC-তে (Monitor পেজে) শেয়ার করা যাবে।</p>

  <h4>ফোনের তথ্য</h4>
  <div class="timerRow">
    <input type="text" id="nicknameInput" placeholder="ফোনের নাম (যেমন: Abu's Phone)" maxlength="40">
    <button onclick="saveNickname()">Save</button>
  </div>
  <div id="batteryInfo" class="uploadStatusText"></div>

  <h4>স্ক্রিন শেয়ার (PC-র Monitor পেজে দেখা যাবে)</h4>
  <button class="topbtn" id="screenShareBtn" onclick="toggleScreenShare()">Share My Screen</button>
  <div id="screenShareNote" class="uploadStatusText"></div>
  <p class="warn">এই ফোনের স্ক্রিন দেখতে PC-র নিজের ব্রাউজারে যান: http://localhost:{port}/monitor</p>

  <h4>কানেক্টেড ফোনসমূহ</h4>
  <div id="phoneList" style="font-size:13px"></div>

  <h4>Session Timer (ফাইল ট্রান্সফারের জন্য)</h4>
  <div class="timerRow">
    <input type="number" id="sessionMinutes" min="1" max="{max_session_min}" value="15">
    <span>মিনিট</span>
    <button onclick="startPhoneSession(false)">Start</button>
    <button onclick="startPhoneSession(true)">Unlimited</button>
    <button onclick="stopPhoneSession()">Stop</button>
    <span id="sessionState" class="off">OFF</span>
    <span id="sessionTimeLeft"></span>
  </div>

  <h4>Phone &rarr; PC (send photos/files)</h4>
  <input type="file" id="phoneFiles" multiple accept="image/*,video/*,*/*">
  <button onclick="uploadToPC()">Upload to PC</button>
  <div id="uploadStatus"></div>

  <h4>PC &rarr; Phone (get files)</h4>
  <button onclick="refreshShareList()">Refresh list</button>
  <div id="fileList"></div>
</div>

<h3>Modifiers</h3>
<div class="row">
<button class="mod" id="m-ctrl" onclick="toggleMod('ctrl')">Ctrl</button>
<button class="mod" id="m-shift" onclick="toggleMod('shift')">Shift</button>
<button class="mod" id="m-alt" onclick="toggleMod('alt')">Alt</button>
<button class="mod" id="m-win" onclick="toggleMod('win')">Win</button>
<button onclick="clearMods()">Clear</button>
</div>

<h3>Letters / Numbers</h3>
<div class="row" id="letters"></div>

<h3>Function Keys</h3>
<div class="row" id="fkeys"></div>

<h3>Special Keys</h3>
<div class="row">
<button onclick="send(['esc'])">Esc</button>
<button onclick="send(['tab'])">Tab</button>
<button onclick="send(['enter'])">Enter</button>
<button onclick="send(['space'])">Space</button>
<button onclick="send(['backspace'])">Backspace</button>
<button onclick="send(['delete'])">Delete</button>
<button onclick="send(['insert'])">Insert</button>
<button onclick="send(['home'])">Home</button>
<button onclick="send(['end'])">End</button>
<button onclick="send(['pageup'])">PgUp</button>
<button onclick="send(['pagedown'])">PgDn</button>
<button onclick="send(['up'])">Up</button>
<button onclick="send(['down'])">Down</button>
<button onclick="send(['left'])">Left</button>
<button onclick="send(['right'])">Right</button>
<button onclick="send(['printscreen'])">PrtScn</button>
<button onclick="send(['scrolllock'])">ScrLk</button>
<button onclick="send(['capslock'])">CapsLock</button>
</div>

<h3>Move Window / Close</h3>
<div class="row">
<button onclick="send(['win','left'])">Move Left</button>
<button onclick="send(['win','right'])">Move Right</button>
<button onclick="send(['win','d'])">Show Desktop</button>
<button onclick="send(['alt','f4'])">Close Window (Alt+F4)</button>
</div>

<h3>Power</h3>
<div class="row">
<button onclick="powerAction('lock')">Lock PC</button>
<button onclick="powerAction('sleep')">Sleep PC</button>
<button onclick="powerAction('restart')">Restart PC</button>
<button onclick="powerAction('shutdown')">Shutdown PC</button>
</div>

<h3>Custom combo</h3>
<div class="row">
<input id="custom" placeholder="e.g. ctrl+shift+esc">
<button onclick="sendCustom()">Run</button>
</div>

<h3>Activity Log</h3>
<div id="log"></div>

<script>
let mods = {ctrl:false, shift:false, alt:false, win:false};

function toggleMod(m){
  mods[m] = !mods[m];
  document.getElementById('m-'+m).classList.toggle('active', mods[m]);
}
function clearMods(){
  for(const m in mods){ mods[m]=false; document.getElementById('m-'+m).classList.remove('active'); }
}
function activeMods(){
  return Object.keys(mods).filter(m=>mods[m]);
}
function send(keys){
  let combo = keys[0] && ['ctrl','shift','alt','win'].includes(keys[0]) ? keys : activeMods().concat(keys);
  fetch('/api/press', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({keys: combo})
  });
}
function sendCustom(){
  const val = document.getElementById('custom').value.trim();
  if(!val) return;
  send(val.split('+').map(s=>s.trim().toLowerCase()));
}

// ---- Power (shutdown / restart / lock) ----
function powerAction(action){
  const labels = {lock:'PC Lock', restart:'PC Restart', shutdown:'PC Shutdown', sleep:'PC Sleep'};
  if(!confirm(labels[action] + ' করতে চান? নিশ্চিত হলে OK চাপুন।')) return;
  fetch('/api/power', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({action: action})
  }).then(r=>r.json()).then(d=>{
    if(d && d.error) alert('Error: ' + d.error);
  });
}

// ---- Full screen ----
function toggleFullscreen(){
  const wrap = document.getElementById('screenWrap');
  if(!document.fullscreenElement){
    wrap.requestFullscreen().catch(()=>{});
    document.getElementById('fsBtn').classList.add('active');
  } else {
    document.exitFullscreen();
    document.getElementById('fsBtn').classList.remove('active');
  }
}

// ---- Touch input mode (Off / Trackpad / Direct touch / 2-finger pan&zoom / 3-finger pan&zoom) ----
let touchMode = 'off';
let screenW = 0, screenH = 0;
const touchModeDescriptions = {
  off: 'টাচ কন্ট্রোল এখন বন্ধ আছে।',
  trackpad: 'Use your touchscreen like a trackpad for precise control of the remote mouse pointer.',
  direct: 'যেখানে ট্যাপ/ড্র্যাগ করবেন, মাউস সরাসরি সেখানে যাবে (আসল টাচস্ক্রিনের মতো)। ২ আঙুলে ট্যাপ করলে রাইট-ক্লিক হবে।',
  pan2: '১ আঙুলে সরাসরি টাচ/ক্লিক, ২ আঙুলে প্যান (স্ক্রল) ও পিঞ্চ করলে জুম হবে।',
  pan3: '১ আঙুলে সরাসরি টাচ/ক্লিক, ২ আঙুলে ট্যাপে রাইট-ক্লিক, ৩ আঙুলে প্যান ও জুম হবে।',
};

function ensureScreenSize(){
  if(screenW && screenH) return;
  fetch('/api/screen_size').then(r=>r.json()).then(d=>{ if(d.ok){ screenW=d.width; screenH=d.height; } });
}

function toggleTouchModePanel(){
  document.getElementById('touchModePanel').classList.toggle('active');
}
function closeTouchModePanel(){
  document.getElementById('touchModePanel').classList.remove('active');
}
document.querySelectorAll('input[name=touchMode]').forEach(r=>{
  r.addEventListener('change', ()=>{
    touchMode = r.value;
    document.getElementById('touchModeDesc').textContent = touchModeDescriptions[touchMode];
    const on = touchMode !== 'off';
    document.getElementById('touchOverlay').classList.toggle('active', on);
    document.getElementById('tpBtn').classList.toggle('active', on);
    if(touchMode !== 'trackpad' && touchMode !== 'off') ensureScreenSize();
  });
});

const overlay = document.getElementById('touchOverlay');
let lastX=0, lastY=0, lastDist=0, lastAvgY=0, touchStartTime=0, moved=0, maxTouches=1;

function dist(a,b){ return Math.hypot(a.clientX-b.clientX, a.clientY-b.clientY); }

function imgFraction(clientX, clientY){
  const img = document.getElementById('screen');
  const rect = img.getBoundingClientRect();
  const fx = Math.max(0, Math.min(1, (clientX-rect.left)/rect.width));
  const fy = Math.max(0, Math.min(1, (clientY-rect.top)/rect.height));
  return {fx, fy};
}
function sendAbsoluteMove(x, y){
  const {fx, fy} = imgFraction(x, y);
  fetch('/api/mouse_absolute', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({fx, fy, click:false})});
}
function sendAbsoluteClick(x, y, button){
  const {fx, fy} = imgFraction(x, y);
  fetch('/api/mouse_absolute', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({fx, fy, click:true, button})});
}
function isPanGesture(n){
  return (touchMode==='trackpad' && n===2) || (touchMode==='pan2' && n===2) || (touchMode==='pan3' && n===3);
}

overlay.addEventListener('touchstart', e=>{
  touchStartTime = Date.now();
  moved = 0;
  maxTouches = e.touches.length;
  if(e.touches.length===1){
    lastX = e.touches[0].clientX; lastY = e.touches[0].clientY;
    if(touchMode==='direct' || touchMode==='pan2' || touchMode==='pan3') sendAbsoluteMove(lastX, lastY);
  } else if(isPanGesture(e.touches.length)){
    const pts = Array.from(e.touches);
    lastDist = dist(pts[0], pts[1]);
    lastAvgY = pts.reduce((s,t)=>s+t.clientY,0)/pts.length;
  }
}, {passive:true});

overlay.addEventListener('touchmove', e=>{
  e.preventDefault();
  const n = e.touches.length;
  maxTouches = Math.max(maxTouches, n);
  if(n===1){
    const x=e.touches[0].clientX, y=e.touches[0].clientY;
    const dx=(x-lastX), dy=(y-lastY);
    moved += Math.abs(dx)+Math.abs(dy);
    if(touchMode==='trackpad'){
      fetch('/api/mouse_move', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({dx, dy})});
    } else if(touchMode==='direct' || touchMode==='pan2' || touchMode==='pan3'){
      sendAbsoluteMove(x, y);
    }
    lastX=x; lastY=y;
  } else if(isPanGesture(n)){
    const pts = Array.from(e.touches);
    const d = dist(pts[0], pts[1]);
    const avgY = pts.reduce((s,t)=>s+t.clientY,0)/pts.length;
    const distDelta = d - lastDist;
    const scrollDelta = avgY - lastAvgY;
    moved += Math.abs(distDelta)+Math.abs(scrollDelta);
    if(Math.abs(distDelta) > Math.abs(scrollDelta)){
      fetch('/api/zoom', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({direction: distDelta>0?1:-1})});
    } else {
      fetch('/api/scroll', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({amount: scrollDelta>0?-1:1})});
    }
    lastDist=d; lastAvgY=avgY;
  }
}, {passive:false});

overlay.addEventListener('touchend', e=>{
  const elapsed = Date.now()-touchStartTime;
  if(elapsed < 300 && moved < 12){
    if(touchMode==='trackpad'){
      fetch('/api/click', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({button: maxTouches>1 ? 'right':'left'})});
    } else if(touchMode==='direct'){
      const t = e.changedTouches[0];
      sendAbsoluteClick(t.clientX, t.clientY, maxTouches>1 ? 'right':'left');
    } else if(touchMode==='pan3'){
      if(maxTouches<=2){
        const t = e.changedTouches[0];
        sendAbsoluteClick(t.clientX, t.clientY, maxTouches===2 ? 'right':'left');
      }
    } else if(touchMode==='pan2'){
      if(maxTouches===1){
        const t = e.changedTouches[0];
        sendAbsoluteClick(t.clientX, t.clientY, 'left');
      }
    }
  }
  if(e.touches.length===0) maxTouches = 1;
}, {passive:true});

// build letter/number buttons
const letters = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM".split("");
const letterRow = document.getElementById('letters');
letters.forEach(l=>{
  const b = document.createElement('button');
  b.textContent = l;
  b.onclick = ()=>send([l.toLowerCase()]);
  letterRow.appendChild(b);
});

// build F1-F12 buttons
const fkeyRow = document.getElementById('fkeys');
for(let i=1;i<=12;i++){
  const b = document.createElement('button');
  b.textContent = 'F'+i;
  b.onclick = ()=>send(['f'+i]);
  fkeyRow.appendChild(b);
}

// ---- Game Controller mode ----
let xboxMode = false;

function toggleGamePanel(){
  const panel = document.getElementById('gamePanel');
  const on = panel.classList.toggle('active');
  document.getElementById('gcBtn').classList.toggle('active', on);
}

function toggleXboxMode(){
  xboxMode = !xboxMode;
  const btn = document.getElementById('xboxModeBtn');
  btn.classList.toggle('active', xboxMode);
  btn.textContent = 'Xbox Controller Mode: ' + (xboxMode ? 'ON' : 'OFF');
  if(xboxMode){
    // quick probe so the user finds out immediately if the PC doesn't
    // have vgamepad/ViGEmBus installed, instead of every press silently failing
    fetch('/api/gamepad/down', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({button:'A'})})
      .then(r=>r.json()).then(d=>{
        fetch('/api/gamepad/up', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({button:'A'})});
        if(!d.ok) alert(d.error || 'PC-তে ভার্চুয়াল Xbox কন্ট্রোলার চালু করা যায়নি।');
      });
  }
}

function holdStart(e, key, xboxBtn){
  if(e) e.preventDefault();
  if(xboxMode && xboxBtn){
    fetch('/api/gamepad/down', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({button: xboxBtn})});
  } else {
    fetch('/api/keydown', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({key})});
  }
}
function holdEnd(e, key, xboxBtn){
  if(e) e.preventDefault();
  if(xboxMode && xboxBtn){
    fetch('/api/gamepad/up', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({button: xboxBtn})});
  } else {
    fetch('/api/keyup', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({key})});
  }
}

// build 2 shoulder buttons (L1/R1 style, like the physical controller's top triggers)
const shoulderKeys = ['q','e'];
const shoulderLabels = ['L1','R1'];
const shoulderXbox = ['LB','RB'];
const shoulderRow = document.getElementById('shoulderRow');
for(let i=0;i<2;i++){
  const wrap = document.createElement('div');
  wrap.className = 'shoulderWrap';
  const input = document.createElement('input');
  input.id = 'shoulder-key-'+i;
  input.value = shoulderKeys[i];
  const btn = document.createElement('button');
  btn.textContent = shoulderLabels[i];
  btn.addEventListener('touchstart', e=>{ e.preventDefault(); holdStart(null, input.value.trim().toLowerCase(), shoulderXbox[i]); }, {passive:false});
  btn.addEventListener('touchend', e=>{ e.preventDefault(); holdEnd(null, input.value.trim().toLowerCase(), shoulderXbox[i]); }, {passive:false});
  btn.addEventListener('mousedown', ()=> holdStart(null, input.value.trim().toLowerCase(), shoulderXbox[i]));
  btn.addEventListener('mouseup', ()=> holdEnd(null, input.value.trim().toLowerCase(), shoulderXbox[i]));
  wrap.appendChild(input);
  wrap.appendChild(btn);
  shoulderRow.appendChild(wrap);
}

// build 4 diamond action buttons (Y/X/B/A style, like the physical controller's right side)
const diamondPositions = [
  {id:'dia-top', label:'Y', key:'space'},
  {id:'dia-left', label:'X', key:'shift'},
  {id:'dia-right', label:'B', key:'ctrl'},
  {id:'dia-bottom', label:'A', key:'f'}
];
const diamond = document.getElementById('diamond');
diamondPositions.forEach(pos=>{
  const wrap = document.createElement('div');
  wrap.className = 'diaBtnWrap';
  wrap.id = pos.id;

  const input = document.createElement('input');
  input.value = pos.key;

  const btn = document.createElement('button');
  btn.textContent = pos.label;
  btn.addEventListener('touchstart', e=>{ e.preventDefault(); holdStart(null, input.value.trim().toLowerCase(), pos.label); }, {passive:false});
  btn.addEventListener('touchend', e=>{ e.preventDefault(); holdEnd(null, input.value.trim().toLowerCase(), pos.label); }, {passive:false});
  btn.addEventListener('mousedown', ()=> holdStart(null, input.value.trim().toLowerCase(), pos.label));
  btn.addEventListener('mouseup', ()=> holdEnd(null, input.value.trim().toLowerCase(), pos.label));

  wrap.appendChild(input);
  wrap.appendChild(btn);
  diamond.appendChild(wrap);
});

// ---- Phone <-> PC transfer panel ----
let phoneCountdownTimer = null;

function togglePhonePanel(){
  const panel = document.getElementById('phonePanel');
  const on = panel.classList.toggle('active');
  document.getElementById('phoneBtn').classList.toggle('active', on);
  if(on){ refreshSessionStatus(); refreshPhoneList(); sendBatteryInfo(); }
}

function setSessionUI(active, secondsLeft){
  const stateEl = document.getElementById('sessionState');
  stateEl.textContent = active ? 'ON' : 'OFF';
  stateEl.className = active ? 'on' : 'off';
  const leftEl = document.getElementById('sessionTimeLeft');
  if(active && secondsLeft > 0){
    const m = Math.floor(secondsLeft/60), s = Math.floor(secondsLeft%60);
    leftEl.textContent = ' (' + m + 'm ' + s + 's left)';
  } else if(active && secondsLeft === -1){
    leftEl.textContent = ' (Unlimited)';
  } else {
    leftEl.textContent = '';
  }
}

function startPhoneCountdown(secondsLeft){
  if(phoneCountdownTimer) clearInterval(phoneCountdownTimer);
  let left = secondsLeft;
  setSessionUI(true, left);
  phoneCountdownTimer = setInterval(()=>{
    left -= 1;
    if(left <= 0){
      clearInterval(phoneCountdownTimer);
      setSessionUI(false, 0);
      return;
    }
    setSessionUI(true, left);
  }, 1000);
}

function startPhoneSession(unlimited){
  const minutes = parseFloat(document.getElementById('sessionMinutes').value) || 0;
  if(!unlimited && minutes <= 0) return;
  fetch('/api/phone/session/start', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({minutes, unlimited})
  }).then(r=>r.json()).then(d=>{
    if(d.ok){
      if(phoneCountdownTimer) clearInterval(phoneCountdownTimer);
      if(d.unlimited){ setSessionUI(true, -1); }
      else { startPhoneCountdown(d.seconds_left); }
      refreshShareList();
    } else { alert(d.error || 'শুরু করা যায়নি'); }
  });
}

function stopPhoneSession(){
  fetch('/api/phone/session/stop', {method:'POST'}).then(r=>r.json()).then(d=>{
    if(phoneCountdownTimer) clearInterval(phoneCountdownTimer);
    setSessionUI(false, 0);
  });
}

function refreshSessionStatus(){
  fetch('/api/phone/session/status').then(r=>r.json()).then(d=>{
    if(d.active){
      if(phoneCountdownTimer) clearInterval(phoneCountdownTimer);
      if(d.unlimited){ setSessionUI(true, -1); }
      else { startPhoneCountdown(d.seconds_left); }
      refreshShareList();
    } else { setSessionUI(false, 0); }
  });
}

// ---- phone nickname / battery ----
function saveNickname(){
  const name = document.getElementById('nicknameInput').value.trim();
  if(!name) return;
  fetch('/api/phone/info', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({nickname:name})}).then(()=> refreshPhoneList());
}

function sendBatteryInfo(){
  if(navigator.getBattery){
    navigator.getBattery().then(b=>{
      const pct = Math.round(b.level*100);
      document.getElementById('batteryInfo').textContent =
        'ব্যাটারি: ' + pct + '%' + (b.charging ? ' (চার্জ হচ্ছে)' : '');
      fetch('/api/phone/info', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({battery: pct})});
    }).catch(()=>{ document.getElementById('batteryInfo').textContent = 'ব্যাটারি তথ্য পাওয়া যায়নি'; });
  } else {
    document.getElementById('batteryInfo').textContent = 'এই ব্রাউজার ব্যাটারি তথ্য দেয় না';
  }
}

function refreshPhoneList(){
  fetch('/api/phones').then(r=>r.json()).then(d=>{
    if(d.error) return;
    const el = document.getElementById('phoneList');
    el.innerHTML = d.phones.map(p=>{
      const bat = p.battery!=null ? Math.round(p.battery)+'%' : '—';
      return '<div>' + (p.connected?'🟢':'⚫') + ' Controller ' + p.slot + ': ' + p.nickname +
             ' | ব্যাটারি ' + bat + (p.screen_live ? ' | 📱 লাইভ স্ক্রিন' : '') + '</div>';
    }).join('');
  });
}

// ---- share this phone's screen so it shows up on the PC's /monitor page ----
// NOTE: this only works in a desktop browser (Chrome/Edge/Firefox on
// Windows/Mac/Linux). Android and iPhone browsers don't implement the
// screen-capture API at all - that's a platform limitation, not a bug
// here - so on a phone the button is disabled with an explanation below it.
(function(){
  const btn = document.getElementById('screenShareBtn');
  const note = document.getElementById('screenShareNote');
  if(!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia){
    btn.disabled = true;
    btn.style.opacity = '0.5';
    note.textContent = 'এই ফিচারটা শুধু PC/Laptop ব্রাউজারে (Chrome/Edge/Firefox) কাজ করে। Android/iPhone ব্রাউজার স্ক্রিন শেয়ার সাপোর্ট করে না - এটা ফোনের ব্রাউজারের সীমাবদ্ধতা, অ্যাপের বাগ না।';
  }
})();
let screenStream = null, screenCaptureTimer = null;
async function toggleScreenShare(){
  const btn = document.getElementById('screenShareBtn');
  if(btn.disabled) return;
  if(screenStream){
    screenStream.getTracks().forEach(t=>t.stop());
    screenStream = null;
    clearInterval(screenCaptureTimer);
    btn.classList.remove('active');
    btn.textContent = 'Share My Screen';
    return;
  }
  if(!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia){
    alert('এই ব্রাউজারে স্ক্রিন শেয়ার সাপোর্ট নেই।');
    return;
  }
  let stream;
  try{ stream = await navigator.mediaDevices.getDisplayMedia({video:true}); }
  catch(e){ return; }
  screenStream = stream;
  const video = document.createElement('video');
  video.srcObject = stream;
  video.muted = true;
  video.play();
  const canvas = document.createElement('canvas');
  btn.classList.add('active');
  btn.textContent = 'Stop Sharing';
  stream.getVideoTracks()[0].addEventListener('ended', ()=>{
    screenStream = null; clearInterval(screenCaptureTimer);
    btn.classList.remove('active'); btn.textContent = 'Share My Screen';
  });
  screenCaptureTimer = setInterval(()=>{
    if(!video.videoWidth) return;
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    canvas.toBlob(blob=>{
      if(!blob) return;
      const fd = new FormData();
      fd.append('frame', blob, 'frame.jpg');
      fetch('/api/phone/screen_frame', {method:'POST', body: fd});
    }, 'image/jpeg', 0.5);
  }, 700);
}

function uploadToPC(){
  const input = document.getElementById('phoneFiles');
  const statusEl = document.getElementById('uploadStatus');
  if(!input.files.length){ statusEl.textContent = 'আগে ছবি/ফাইল বেছে নিন।'; return; }
  const fd = new FormData();
  for(const f of input.files) fd.append('files', f);
  statusEl.textContent = 'আপলোড হচ্ছে...';
  fetch('/api/phone/upload', {method:'POST', body: fd})
    .then(r=>r.json())
    .then(d=>{
      if(d.ok){ statusEl.textContent = d.saved + ' টা ফাইল পিসিতে পাঠানো হয়েছে ✅'; input.value=''; }
      else { statusEl.textContent = 'এরর: ' + (d.error || 'সেশন চালু নেই, আগে Start চাপুন'); }
    })
    .catch(()=>{ statusEl.textContent = 'আপলোড ফেইল হয়েছে।'; });
}

function refreshShareList(){
  fetch('/api/phone/files').then(r=>r.json()).then(d=>{
    const list = document.getElementById('fileList');
    list.innerHTML = '';
    if(d.error){ list.innerHTML = '<div style="color:#ff6b6b">' + d.error + '</div>'; return; }
    if(!d.files.length){ list.innerHTML = '<div style="color:#777">এখনো কোনো ফাইল নেই</div>'; return; }
    d.files.forEach(name=>{
      const a = document.createElement('a');
      a.href = '/api/phone/download/' + encodeURIComponent(name);
      a.textContent = '⬇ ' + name;
      a.setAttribute('download', name);
      list.appendChild(a);
    });
  });
}

// ---- PC app launcher ("Apps" panel) ----
function toggleAppsPanel(){
  const panel = document.getElementById('appsPanel');
  const on = panel.classList.toggle('active');
  document.getElementById('appsBtn').classList.toggle('active', on);
  if(on) refreshAppsList();
}
function refreshAppsList(){
  fetch('/api/apps').then(r=>r.json()).then(d=>{
    const el = document.getElementById('appsListEl');
    if(d.error){ el.textContent = d.error; return; }
    el.innerHTML = d.apps.map(a=>
      '<div class="appRow"><span>'+a.name+'</span><span>'+
      '<button onclick="launchApp(\\''+a.name.replace(/'/g,"\\\\'")+'\\')">Open</button>'+
      '<button class="rm" onclick="removeApp(\\''+a.name.replace(/'/g,"\\\\'")+'\\')">&times;</button>'+
      '</span></div>'
    ).join('') || '<div style="color:#777">কোনো app নেই</div>';
  });
}
function launchApp(name){
  fetch('/api/apps/launch', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name})}).then(r=>r.json()).then(d=>{ if(d.error) alert('Error: '+d.error); });
}
function removeApp(name){
  if(!confirm(name+' লিস্ট থেকে বাদ দিতে চান?')) return;
  fetch('/api/apps/remove', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name})}).then(()=> refreshAppsList());
}
function addApp(){
  const name = document.getElementById('newAppName').value.trim();
  const path = document.getElementById('newAppPath').value.trim();
  if(!name || !path){ alert('নাম ও path দুটোই দিন'); return; }
  fetch('/api/apps/add', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name, path})}).then(r=>r.json()).then(d=>{
      if(d.ok){
        document.getElementById('newAppName').value='';
        document.getElementById('newAppPath').value='';
        refreshAppsList();
      } else alert('Error: '+(d.error||''));
    });
}

// heartbeat so this controller slot stays reserved
setInterval(()=>{ fetch('/api/heartbeat', {method:'POST'}); }, 5000);
setInterval(sendBatteryInfo, 30000);
setInterval(refreshPhoneList, 4000);

// poll activity log
setInterval(()=>{
  fetch('/api/log').then(r=>r.json()).then(d=>{
    document.getElementById('log').innerHTML = d.log.map(l=>'<div>'+l+'</div>').join('');
  });
}, 1500);
</script>
</body></html>
"""


def render_control():
    slot = session.get("slot", "?")
    return (CONTROL_HTML
            .replace("{logo}", LOGO_SVG)
            .replace("{slot}", str(slot))
            .replace("{max_ctrl}", str(MAX_CONTROLLERS))
            .replace("{max_session_min}", str(PHONE_SESSION_MAX_MINUTES))
            .replace("{port}", str(PORT))
            .replace("{pcname}", PC_NAME)
            .replace("{pcip}", PC_LOCAL_IP if PC_LOCAL_IP else "IP not available"))


# ---------------------------------------------------------
# Routes
# ---------------------------------------------------------
def is_local_request():
    """True only when the request is coming from this PC itself (used to
    keep account creation PC-owner-only - phones on the network can Sign
    In, but only the person sitting at the PC can create/manage accounts,
    normally via the Abu AI Desktop app's own window)."""
    return request.remote_addr in ("127.0.0.1", "::1", "localhost")


@app.route('/login', methods=['GET', 'POST'])
def login():
    # No accounts exist yet at all.
    if not users_list:
        if is_local_request():
            return redirect(url_for('signup'))
        return render_login(
            '<p class="err">এই PC-তে এখনো কোনো account সেট করা হয়নি। '
            'PC-এর মালিককে বলুন Abu AI Desktop app থেকে প্রথম account তৈরি করে দিতে।</p>')
    if request.method == 'POST':
        uname = (request.form.get('username') or "").strip()
        remember = bool(request.form.get('remember'))
        user_exists = any(u["username"] == uname for u in users_list)

        if is_locked_out(uname):
            return render_login(
                f'<p class="err">অনেকবার ভুল Password দেওয়া হয়েছে — '
                f'{LOGIN_LOCK_SECONDS} সেকেন্ড পর আবার চেষ্টা করুন।</p>')

        if check_credentials(uname, request.form.get('password')):
            clear_failed_logins(uname)
            with lock:
                # reuse existing slot if this session already has one
                sid = session.get("sid")
                existing_slot = None
                if sid:
                    for s, v in controllers.items():
                        if v["sid"] == sid:
                            existing_slot = s
                            break
                if existing_slot:
                    controllers[existing_slot]["last_seen"] = time.time()
                    session["slot"] = existing_slot
                else:
                    free_slot = None
                    for s in range(1, MAX_CONTROLLERS + 1):
                        if s not in controllers:
                            free_slot = s
                            break
                    if free_slot is None:
                        return render_login('<p class="err">সবগুলো কন্ট্রোলার স্লট (৩টা) ভর্তি, পরে চেষ্টা করুন।</p>')
                    new_sid = secrets.token_hex(8)
                    session["sid"] = new_sid
                    session["slot"] = free_slot
                    controllers[free_slot] = {"sid": new_sid, "last_seen": time.time()}
            session.permanent = remember  # "Remember Me" checked -> stay logged in ~14 days instead of just this browser session
            session['auth'] = True
            log_action(session["slot"], "connected" + (" (remembered)" if remember else ""))
            return redirect(url_for('control'))

        if user_exists:
            register_failed_login(uname)
            return render_login('<p class="err">ভুল Username/Password</p>')
        # username doesn't exist on this PC - phones can't self-signup anymore,
        # so just point them to the PC owner instead of a signup link.
        return render_login(
            '<p class="err">এই নামে কোনো account নেই এই PC-তে। '
            'PC-এর মালিককে বলুন Abu AI Desktop app থেকে আপনার account যোগ করে দিতে।</p>')
    return render_login("")


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    # Account creation is PC-owner-only: reachable from this computer's own
    # browser (or the desktop app, which calls the same logic directly),
    # but not from a phone elsewhere on the Wi-Fi.
    if not is_local_request():
        return redirect(url_for('login'))
    if len(users_list) >= MAX_CONTROLLERS:
        return redirect(url_for('login'))
    if request.method == 'POST':
        uname = (request.form.get('username') or "").strip()
        upass = request.form.get('password') or ""
        upass2 = request.form.get('password2') or ""
        if not uname:
            return render_signup('<p class="err">Username দিন</p>')
        if any(u["username"] == uname for u in users_list):
            return render_signup('<p class="err">এই নামে আগে থেকেই একটা account আছে</p>')
        if len(upass) < 4:
            return render_signup('<p class="err">Password কমপক্ষে ৪ অক্ষরের হতে হবে</p>')
        if upass != upass2:
            return render_signup('<p class="err">দুইবার লেখা Password মিলছে না</p>')
        with lock:
            users_list.append({"username": uname, "password_hash": generate_password_hash(upass)})
            save_users(users_list)
        # account created - log them straight in, same as /login does
        with lock:
            free_slot = None
            for s in range(1, MAX_CONTROLLERS + 1):
                if s not in controllers:
                    free_slot = s
                    break
            if free_slot is None:
                return redirect(url_for('login'))
            new_sid = secrets.token_hex(8)
            session["sid"] = new_sid
            session["slot"] = free_slot
            controllers[free_slot] = {"sid": new_sid, "last_seen": time.time()}
        session['auth'] = True
        log_action(session["slot"], f"account '{uname}' created and connected")
        return redirect(url_for('control'))
    return render_signup("")


@app.route('/')
def control():
    if not session.get('auth'):
        return redirect(url_for('login'))
    return render_control()


@app.route('/stream')
def stream():
    if not session.get('auth'):
        return "Unauthorized", 401
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


def require_auth():
    return session.get('auth') and session.get('slot') in controllers


@app.route('/api/heartbeat', methods=['POST'])
def heartbeat():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    with lock:
        controllers[session["slot"]]["last_seen"] = time.time()
    return jsonify(ok=True)


def do_power_action(action):
    """Runs the OS-native shutdown / restart / lock command for this PC."""
    system = platform.system()
    if action == "shutdown":
        if system == "Windows":
            os.system("shutdown /s /t 0")
        elif system == "Darwin":
            os.system("osascript -e 'tell app \"System Events\" to shut down'")
        else:
            os.system("shutdown -h now")
    elif action == "restart":
        if system == "Windows":
            os.system("shutdown /r /t 0")
        elif system == "Darwin":
            os.system("osascript -e 'tell app \"System Events\" to restart'")
        else:
            os.system("shutdown -r now")
    elif action == "lock":
        if system == "Windows":
            os.system("rundll32.exe user32.dll,LockWorkStation")
        elif system == "Darwin":
            os.system("pmset displaysleepnow")
        else:
            os.system("loginctl lock-session || xdg-screensaver lock || true")
    elif action == "sleep":
        if system == "Windows":
            os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        elif system == "Darwin":
            os.system("pmset sleepnow")
        else:
            os.system("systemctl suspend || xdg-screensaver lock || true")


@app.route('/api/power', methods=['POST'])
def api_power():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    action = (data.get('action') or '').strip().lower()
    if action not in ("shutdown", "restart", "lock", "sleep"):
        return jsonify(error="bad action"), 400
    slot = session["slot"]
    log_action(slot, f"requested PC {action}")
    try:
        do_power_action(action)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/press', methods=['POST'])
def api_press():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    keys = [k for k in data.get('keys', []) if k]
    if not keys:
        return jsonify(error="no keys"), 400
    try:
        if len(keys) == 1:
            pyautogui.press(keys[0])
        else:
            pyautogui.hotkey(*keys)
        log_action(session["slot"], "pressed " + "+".join(keys))
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/keydown', methods=['POST'])
def api_keydown():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    key = (data.get('key') or '').strip().lower()
    if not key:
        return jsonify(error="no key"), 400
    try:
        pyautogui.keyDown(key)
        log_action(session["slot"], f"holding {key}")
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/keyup', methods=['POST'])
def api_keyup():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    key = (data.get('key') or '').strip().lower()
    if not key:
        return jsonify(error="no key"), 400
    try:
        pyautogui.keyUp(key)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/mouse_move', methods=['POST'])
def api_mouse_move():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    dx = float(data.get('dx', 0)) * MOUSE_SENSITIVITY
    dy = float(data.get('dy', 0)) * MOUSE_SENSITIVITY
    try:
        pyautogui.moveRel(dx, dy, duration=0)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/click', methods=['POST'])
def api_click():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    button = data.get('button', 'left')
    try:
        pyautogui.click(button=button)
        log_action(session["slot"], f"{button} click")
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/scroll', methods=['POST'])
def api_scroll():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    amount = int(data.get('amount', 0)) * 40
    try:
        pyautogui.scroll(amount)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/zoom', methods=['POST'])
def api_zoom():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    direction = int(data.get('direction', 0))
    try:
        pyautogui.keyDown('ctrl')
        pyautogui.scroll(direction * 60)
        pyautogui.keyUp('ctrl')
        log_action(session["slot"], "zoom " + ("in" if direction > 0 else "out"))
        return jsonify(ok=True)
    except Exception as e:
        pyautogui.keyUp('ctrl')
        return jsonify(error=str(e)), 500


@app.route('/api/screen_size')
def api_screen_size():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    return jsonify(ok=True, width=SCREEN_W, height=SCREEN_H)


@app.route('/api/mouse_absolute', methods=['POST'])
def api_mouse_absolute():
    """Used by 'Direct touch' / 'pan & zoom' touch modes: moves the PC
    mouse to an exact point on the screen (fx/fy are 0..1 fractions of
    the screen image the phone tapped/dragged), instead of a relative
    trackpad-style drag."""
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    fx, fy = data.get('fx'), data.get('fy')
    if fx is None or fy is None:
        return jsonify(error="fx/fy missing"), 400
    try:
        fx = max(0.0, min(1.0, float(fx)))
        fy = max(0.0, min(1.0, float(fy)))
        x, y = int(fx * SCREEN_W), int(fy * SCREEN_H)
        if data.get('click'):
            button = data.get('button', 'left')
            pyautogui.click(x=x, y=y, button=button)
            log_action(session["slot"], f"direct-touch {button} click")
        else:
            pyautogui.moveTo(x, y, duration=0)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


# ---------------------------------------------------------
# PC app launcher (the "Apps" panel on the phone)
# ---------------------------------------------------------
@app.route('/api/apps')
def api_apps():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    return jsonify(apps=apps_list)


@app.route('/api/apps/add', methods=['POST'])
def api_apps_add():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get('name') or '').strip()[:60]
    path = (data.get('path') or '').strip()[:300]
    if not name or not path:
        return jsonify(error="নাম ও path/command দুটোই দিন"), 400
    with lock:
        apps_list.append({"name": name, "path": path})
        save_apps(apps_list)
    log_action(session["slot"], f"added app '{name}'")
    return jsonify(ok=True, apps=apps_list)


@app.route('/api/apps/remove', methods=['POST'])
def api_apps_remove():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get('name') or '').strip()
    with lock:
        apps_list[:] = [a for a in apps_list if a["name"] != name]
        save_apps(apps_list)
    return jsonify(ok=True, apps=apps_list)


@app.route('/api/apps/launch', methods=['POST'])
def api_apps_launch():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get('name') or '').strip()
    entry = next((a for a in apps_list if a["name"] == name), None)
    if not entry:
        return jsonify(error="app খুঁজে পাওয়া যায়নি"), 404
    path = entry["path"]
    try:
        if platform.system() == "Windows":
            # os.startfile resolves names the SAME way Windows' own Run (Win+R)
            # box does - including apps registered under the "App Paths"
            # registry key (chrome, most installed desktop apps) even when
            # they are NOT on the system PATH. This is why plain
            # subprocess.Popen("chrome", shell=True) used to silently fail.
            try:
                os.startfile(path)
            except OSError:
                # fallback for custom commands with flags/arguments, e.g.
                # "start ms-settings:" or "notepad C:\\some\\file.txt"
                subprocess.Popen(path, shell=True)
        else:
            subprocess.Popen(shlex.split(path))
        log_action(session["slot"], f"launched app '{name}'")
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=f"'{name}' চালু করা যায়নি: {e}"), 500


@app.route('/api/log')
def api_log():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    with lock:
        return jsonify(log=list(activity_log))


# ---------------------------------------------------------
# Phone <-> PC file transfer
# ---------------------------------------------------------
def _phone_session_active(slot):
    s = phone_sessions.get(slot)
    if not s or not s.get("active"):
        return False
    if s.get("unlimited"):
        return True
    if time.time() >= s.get("expires_at", 0):
        s["active"] = False
        return False
    return True


@app.route('/api/phone/session/start', methods=['POST'])
def phone_session_start():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    data = request.get_json(force=True, silent=True) or {}
    slot = session["slot"]
    if data.get('unlimited'):
        with lock:
            phone_sessions[slot] = {"active": True, "unlimited": True, "expires_at": None}
        log_action(slot, "started phone transfer session (unlimited)")
        return jsonify(ok=True, unlimited=True, seconds_left=-1)
    try:
        minutes = float(data.get('minutes', 0))
    except (TypeError, ValueError):
        return jsonify(error="minutes ভুল"), 400
    if minutes <= 0 or minutes > PHONE_SESSION_MAX_MINUTES:
        return jsonify(error=f"minutes ১ থেকে {PHONE_SESSION_MAX_MINUTES} এর মধ্যে দিন"), 400
    expires_at = time.time() + minutes * 60
    with lock:
        phone_sessions[slot] = {"active": True, "unlimited": False, "expires_at": expires_at}
    log_action(slot, f"started phone transfer session ({minutes:g} min)")
    return jsonify(ok=True, unlimited=False, seconds_left=int(minutes * 60))


@app.route('/api/phone/session/stop', methods=['POST'])
def phone_session_stop():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    slot = session["slot"]
    with lock:
        if slot in phone_sessions:
            phone_sessions[slot]["active"] = False
    log_action(slot, "stopped phone transfer session")
    return jsonify(ok=True)


@app.route('/api/phone/session/status')
def phone_session_status():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    slot = session["slot"]
    active = _phone_session_active(slot)
    s = phone_sessions.get(slot, {})
    unlimited = bool(s.get("unlimited")) if active else False
    if active and unlimited:
        seconds_left = -1
    elif active:
        seconds_left = int(s["expires_at"] - time.time())
    else:
        seconds_left = 0
    return jsonify(active=active, unlimited=unlimited, seconds_left=seconds_left)


@app.route('/api/phone/upload', methods=['POST'])
def phone_upload():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    slot = session["slot"]
    if not _phone_session_active(slot):
        return jsonify(error="সেশন চালু নেই, আগে Start চাপুন"), 403
    files = request.files.getlist('files')
    if not files:
        return jsonify(error="কোনো ফাইল পাওয়া যায়নি"), 400
    dest_dir = os.path.join(PHONE_UPLOAD_DIR, f"controller{slot}")
    os.makedirs(dest_dir, exist_ok=True)
    saved = 0
    for f in files:
        if not f or not f.filename:
            continue
        name = secure_filename(f.filename)
        if not name:
            continue
        # avoid overwriting files with the same name
        base, ext = os.path.splitext(name)
        path = os.path.join(dest_dir, name)
        i = 1
        while os.path.exists(path):
            path = os.path.join(dest_dir, f"{base}_{i}{ext}")
            i += 1
        f.save(path)
        saved += 1
    log_action(slot, f"uploaded {saved} file(s) from phone")
    return jsonify(ok=True, saved=saved)


@app.route('/api/phone/files')
def phone_files():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    slot = session["slot"]
    if not _phone_session_active(slot):
        return jsonify(error="সেশন চালু নেই, আগে Start চাপুন"), 403
    try:
        names = sorted(
            f for f in os.listdir(PC_SHARE_DIR)
            if os.path.isfile(os.path.join(PC_SHARE_DIR, f))
        )
    except OSError as e:
        return jsonify(error=str(e)), 500
    return jsonify(files=names)


@app.route('/api/phone/download/<path:filename>')
def phone_download(filename):
    if not require_auth():
        return "Unauthorized", 401
    slot = session["slot"]
    if not _phone_session_active(slot):
        return "Session not active", 403
    safe_name = secure_filename(filename)
    if not safe_name or not os.path.isfile(os.path.join(PC_SHARE_DIR, safe_name)):
        return "Not found", 404
    log_action(slot, f"downloaded {safe_name} to phone")
    return send_from_directory(PC_SHARE_DIR, safe_name, as_attachment=True)


# ---------------------------------------------------------
# Phone info (nickname/battery) + connected-phones list
# ---------------------------------------------------------
@app.route('/api/phone/info', methods=['POST'])
def phone_info_update():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    slot = session["slot"]
    data = request.get_json(force=True, silent=True) or {}
    with lock:
        info = phone_info.setdefault(slot, {"nickname": f"Phone {slot}", "battery": None})
        if data.get('nickname'):
            info['nickname'] = str(data['nickname'])[:40]
        if 'battery' in data:
            try:
                info['battery'] = float(data['battery'])
            except (TypeError, ValueError):
                pass
    return jsonify(ok=True)


@app.route('/api/phones')
def api_phones():
    if not (session.get('auth') or session.get('monitor_auth')):
        return jsonify(error="unauthorized"), 401
    now = time.time()
    out = []
    with lock:
        for s in range(1, MAX_CONTROLLERS + 1):
            info = phone_info.get(s, {})
            screen = phone_screens.get(s)
            out.append({
                "slot": s,
                "connected": s in controllers,
                "nickname": info.get("nickname", f"Phone {s}"),
                "battery": info.get("battery"),
                "screen_live": bool(screen and now - screen["ts"] < PHONE_SCREEN_STALE_SECONDS),
            })
    return jsonify(phones=out)


# ---------------------------------------------------------
# Phone screen mirroring (phone sends frames, PC's /monitor watches them)
# ---------------------------------------------------------
@app.route('/api/phone/screen_frame', methods=['POST'])
def phone_screen_frame():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    slot = session["slot"]
    f = request.files.get('frame')
    if not f:
        return jsonify(error="no frame"), 400
    phone_screens[slot] = {"jpeg": f.read(), "ts": time.time()}
    return jsonify(ok=True)


@app.route('/phone_stream/<int:slot>')
def phone_stream(slot):
    if not (session.get('auth') or session.get('monitor_auth')):
        return "Unauthorized", 401
    return Response(generate_phone_frames(slot), mimetype='multipart/x-mixed-replace; boundary=frame')


# ---------------------------------------------------------
# Real Xbox-controller emulation (needs vgamepad + ViGEmBus, Windows only)
# ---------------------------------------------------------
@app.route('/api/gamepad/down', methods=['POST'])
def gamepad_down():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    if not XBOX_AVAILABLE:
        return jsonify(error="PC-তে vgamepad/ViGEmBus ইনস্টল করা নেই (pip install vgamepad, + ViGEmBus driver, Windows only)"), 400
    slot = session["slot"]
    data = request.get_json(force=True, silent=True) or {}
    btn = (data.get('button') or '').upper()
    attr = XBOX_BUTTON_MAP.get(btn)
    gp = gamepads.get(slot)
    if not attr or not gp:
        return jsonify(error="bad button/slot"), 400
    try:
        gp.press_button(button=getattr(vg.XUSB_BUTTON, attr))
        gp.update()
        log_action(slot, f"xbox {btn} down")
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/api/gamepad/up', methods=['POST'])
def gamepad_up():
    if not require_auth():
        return jsonify(error="unauthorized"), 401
    if not XBOX_AVAILABLE:
        return jsonify(error="PC-তে vgamepad/ViGEmBus ইনস্টল করা নেই (pip install vgamepad, + ViGEmBus driver, Windows only)"), 400
    slot = session["slot"]
    data = request.get_json(force=True, silent=True) or {}
    btn = (data.get('button') or '').upper()
    attr = XBOX_BUTTON_MAP.get(btn)
    gp = gamepads.get(slot)
    if not attr or not gp:
        return jsonify(error="bad button/slot"), 400
    try:
        gp.release_button(button=getattr(vg.XUSB_BUTTON, attr))
        gp.update()
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500


# ---------------------------------------------------------
# Monitor page - open THIS on the PC's own browser to see connected
# phones' names, battery, and (if they turned on "Share My Screen")
# a live mirror of their screen.
# ---------------------------------------------------------
MONITOR_HTML = """
<!DOCTYPE html>
<html><head><title>Abu AI - Monitor</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial;background:#111;color:#eee;margin:0;padding:16px}
h2{margin-top:0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
.card{background:#1c1c1c;border-radius:10px;padding:10px}
.card h3{margin:0 0 6px;font-size:16px}
.card img{width:100%;border-radius:6px;background:#000;min-height:150px;object-fit:contain}
.meta{font-size:13px;color:#aaa;margin-top:6px}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}
.on{background:#4CAF50}
.off{background:#666}
.headerRow{display:flex;align-items:center;gap:8px}
.headerRow .logo{width:34px;height:34px}
</style></head>
<body>
<div class="headerRow">{logo}<h2>Abu AI - Phone Monitor</h2></div>
<div class="grid" id="grid"></div>
<script>
let built = false;
function renderCard(p){
  return '<div class="card" id="card-'+p.slot+'"><h3 id="title-'+p.slot+'"></h3>'+
         '<img id="img-'+p.slot+'" src="/phone_stream/'+p.slot+'">'+
         '<div class="meta" id="meta-'+p.slot+'"></div></div>';
}
function updateCard(p){
  document.getElementById('title-'+p.slot).innerHTML =
    '<span class="dot '+(p.connected?'on':'off')+'"></span>Controller '+p.slot+' - '+p.nickname;
  const bat = p.battery!=null ? Math.round(p.battery)+'%' : '—';
  document.getElementById('meta-'+p.slot).textContent =
    'Battery: '+bat+' | '+(p.connected?'Connected':'Disconnected')+(p.screen_live?' | Live screen':' | Not sharing screen');
  document.getElementById('img-'+p.slot).style.display = p.screen_live ? 'block' : 'none';
}
function render(){
  fetch('/api/phones').then(r=>r.json()).then(d=>{
    if(d.error) return;
    if(!built){
      document.getElementById('grid').innerHTML = d.phones.map(renderCard).join('');
      built = true;
    }
    d.phones.forEach(updateCard);
  });
}
render();
setInterval(render, 4000);
</script>
</body></html>
"""


def check_credentials(username, password):
    username = (username or "").strip()
    user = next((u for u in users_list if u["username"] == username), None)
    if not user:
        return False
    return check_password_hash(user["password_hash"], password or "")


def is_locked_out(username):
    entry = failed_logins.get(username)
    if not entry:
        return False
    if entry.get("locked_until", 0) > time.time():
        return True
    return False


def register_failed_login(username):
    with lock:
        entry = failed_logins.setdefault(username, {"count": 0, "locked_until": 0})
        entry["count"] += 1
        if entry["count"] >= LOGIN_FAIL_LIMIT:
            entry["locked_until"] = time.time() + LOGIN_LOCK_SECONDS
            entry["count"] = 0


def clear_failed_logins(username):
    with lock:
        failed_logins.pop(username, None)


@app.route('/monitor/login', methods=['GET', 'POST'])
def monitor_login():
    if request.method == 'POST':
        if check_credentials(request.form.get('username'), request.form.get('password')):
            session['monitor_auth'] = True
            return redirect(url_for('monitor'))
        return render_login('<p class="err">ভুল Username/Password</p>')
    return render_login("")


@app.route('/monitor')
def monitor():
    if not (session.get('auth') or session.get('monitor_auth')):
        return redirect(url_for('monitor_login'))
    return MONITOR_HTML.replace("{logo}", LOGO_SVG)


def start_server():
    """Starts the Flask server. Called either by running this file directly
    (python abu_robot_server.py) or from abu_ai_launcher.py's GUI window."""
    print(f"Abu AI server starting on port {PORT}")
    print(f"This computer: {PC_NAME}  |  Local IP: {PC_LOCAL_IP or 'not available'}")
    if PC_LOCAL_IP:
        print(f"On each phone (same Wi-Fi), open a browser and go to: http://{PC_LOCAL_IP}:{PORT}")
    else:
        print("On each phone (same Wi-Fi), open a browser and go to: http://<this-pc-ip>:%d" % PORT)
    if not users_list:
        print("কোনো account নেই এখনো - PC-তে http://localhost:%d/signup খুলে (অথবা Abu AI Desktop app "
              "থেকে) প্রথম account তৈরি করুন।" % PORT)
    print("To watch connected phones (names/battery/mirrored screens) on THIS PC, open:")
    print("http://localhost:%d/monitor" % PORT)
    if not XBOX_AVAILABLE:
        print("(Xbox Controller Mode is OFF: install 'pip install vgamepad' + the ViGEmBus driver on Windows to enable it.)")
    app.run(host='0.0.0.0', port=PORT, threaded=True)


if __name__ == '__main__':
    start_server()