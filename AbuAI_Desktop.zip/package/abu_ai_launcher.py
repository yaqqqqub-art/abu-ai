"""
Abu AI Desktop - Launcher (GUI)
----------------------------------------------------
Run THIS file (or its .exe build) instead of typing anything into a
command prompt. It opens a proper window on the PC where you:

  - Create the first Abu AI account (Username + Password)
  - Add / change-password / delete accounts (up to 3), all from the PC
    itself - phones on the Wi-Fi can only Sign In, never create accounts
  - See this computer's name + local IP (the address phones need to type)
  - Start / Stop the Abu AI server with one click
  - Watch a live log of who connected and what they did
  - Copy the connect address to the clipboard in one click

Requirements: same as abu_robot_server.py, plus nothing extra - Tkinter
ships with a normal Python install on Windows/Mac. Just run:
    python abu_ai_launcher.py
"""

import threading
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox

import abu_robot_server as srv          # the actual Flask server + all its state
from werkzeug.serving import make_server


# ---------------------------------------------------------
# A real start/stop-able server (app.run() alone can't be stopped cleanly)
# ---------------------------------------------------------
class ServerThread(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._srv = make_server('0.0.0.0', srv.PORT, srv.app, threaded=True)

    def run(self):
        self._srv.serve_forever()

    def shutdown(self):
        self._srv.shutdown()


class AbuAILauncher:
    def __init__(self, root):
        self.root = root
        self.server_thread = None
        root.title("Abu AI Desktop")
        root.configure(bg="#0d0d0d")
        root.geometry("460x640")
        root.minsize(420, 560)

        # ---------- header (canvas logo, since no image file is bundled) ----------
        header = tk.Frame(root, bg="#0d0d0d")
        header.pack(pady=(18, 6))
        logo = tk.Canvas(header, width=64, height=64, bg="#0d0d0d", highlightthickness=0)
        logo.create_oval(3, 3, 61, 61, outline="#4CAF50", width=3, fill="#132a17")
        logo.create_text(32, 34, text="A", fill="#4CAF50", font=("Arial", 26, "bold"))
        logo.pack()
        tk.Label(header, text="Abu AI Desktop", fg="#eef1ec", bg="#0d0d0d",
                 font=("Arial", 18, "bold")).pack(pady=(6, 0))
        tk.Label(header, text="PC থেকে account সেট করুন, তারপর সার্ভার চালু করুন",
                 fg="#888", bg="#0d0d0d", font=("Arial", 10)).pack()

        # ---------- this computer's identity ----------
        pc_box = tk.Frame(root, bg="#141414")
        pc_box.pack(fill="x", padx=18, pady=10)
        ip_text = srv.PC_LOCAL_IP if srv.PC_LOCAL_IP else "IP not available"
        tk.Label(pc_box, text=f"এই PC: {srv.PC_NAME}", fg="#eee", bg="#141414",
                 font=("Arial", 10, "bold")).pack(anchor="w", padx=10, pady=(8, 0))
        tk.Label(pc_box, text=f"Address (ফোনে লিখুন): http://{ip_text}:{srv.PORT}",
                 fg="#8fd18f", bg="#141414", font=("Consolas", 10)).pack(anchor="w", padx=10, pady=(0, 8))
        tk.Button(pc_box, text="Copy Address", command=self.copy_address,
                  bg="#333", fg="#eee", relief="flat").pack(anchor="e", padx=10, pady=(0, 8))

        # ---------- accounts ----------
        acc_label_row = tk.Frame(root, bg="#0d0d0d")
        acc_label_row.pack(fill="x", padx=18, pady=(4, 2))
        tk.Label(acc_label_row, text="Accounts (সর্বোচ্চ ৩টা)", fg="#eee", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(side="left")
        self.slots_label = tk.Label(acc_label_row, text="", fg="#888", bg="#0d0d0d", font=("Arial", 9))
        self.slots_label.pack(side="right")

        self.accounts_list = tk.Listbox(root, height=4, bg="#141414", fg="#eee",
                                         selectbackground="#4CAF50", relief="flat", highlightthickness=0)
        self.accounts_list.pack(fill="x", padx=18)

        acc_btns = tk.Frame(root, bg="#0d0d0d")
        acc_btns.pack(fill="x", padx=18, pady=8)
        tk.Button(acc_btns, text="+ Add Account", command=self.add_account,
                  bg="#4CAF50", fg="#08130a", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 4))
        tk.Button(acc_btns, text="Change Password", command=self.change_password,
                  bg="#2196F3", fg="white", relief="flat").pack(side="left", expand=True, fill="x", padx=4)
        tk.Button(acc_btns, text="Delete", command=self.delete_account,
                  bg="#a33", fg="white", relief="flat").pack(side="left", expand=True, fill="x", padx=(4, 0))

        # ---------- server controls ----------
        srv_box = tk.Frame(root, bg="#0d0d0d")
        srv_box.pack(fill="x", padx=18, pady=(10, 4))
        self.start_btn = tk.Button(srv_box, text="▶ Start Server", command=self.start_server,
                                    bg="#4CAF50", fg="#08130a", font=("Arial", 12, "bold"), relief="flat")
        self.start_btn.pack(side="left", expand=True, fill="x", padx=(0, 4), ipady=6)
        self.stop_btn = tk.Button(srv_box, text="■ Stop Server", command=self.stop_server,
                                   bg="#333", fg="#888", font=("Arial", 12, "bold"), relief="flat", state="disabled")
        self.stop_btn.pack(side="left", expand=True, fill="x", padx=(4, 0), ipady=6)

        self.status_label = tk.Label(root, text="● সার্ভার বন্ধ আছে", fg="#888", bg="#0d0d0d", font=("Arial", 10))
        self.status_label.pack(pady=(2, 8))

        # ---------- activity log ----------
        tk.Label(root, text="Activity Log", fg="#eee", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=18)
        self.log_text = tk.Text(root, height=7, bg="#141414", fg="#8fd18f", relief="flat",
                                 highlightthickness=0, font=("Consolas", 9), state="disabled")
        self.log_text.pack(fill="both", expand=True, padx=18, pady=(4, 10))

        # ---------- features footer ----------
        tk.Label(root, text="Screen • Touchpad • Apps launcher • File transfer • Game controller — up to 3 phones",
                 fg="#666", bg="#0d0d0d", font=("Arial", 8), wraplength=420).pack(pady=(0, 10))

        self.refresh_accounts()
        self.poll_log()
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------- accounts ----------------
    def refresh_accounts(self):
        self.accounts_list.delete(0, tk.END)
        for u in srv.users_list:
            self.accounts_list.insert(tk.END, u["username"])
        self.slots_label.config(text=f"{len(srv.users_list)}/{srv.MAX_CONTROLLERS} ব্যবহৃত")

    def add_account(self):
        if len(srv.users_list) >= srv.MAX_CONTROLLERS:
            messagebox.showinfo("Abu AI", "সর্বোচ্চ ৩টা account হয়ে গেছে।")
            return
        uname = simpledialog.askstring("নতুন Account", "Username:", parent=self.root)
        if not uname:
            return
        uname = uname.strip()
        if not uname:
            return
        if any(u["username"] == uname for u in srv.users_list):
            messagebox.showerror("Abu AI", "এই নামে আগে থেকেই একটা account আছে।")
            return
        pw = simpledialog.askstring("Password", "Password (কমপক্ষে ৪ অক্ষর):", parent=self.root, show="*")
        if not pw or len(pw) < 4:
            messagebox.showerror("Abu AI", "Password কমপক্ষে ৪ অক্ষরের হতে হবে।")
            return
        srv.users_list.append({"username": uname, "password_hash": srv.generate_password_hash(pw)})
        srv.save_users(srv.users_list)
        self.refresh_accounts()
        messagebox.showinfo("Abu AI", f"'{uname}' account তৈরি হয়েছে।")

    def _selected_username(self):
        sel = self.accounts_list.curselection()
        if not sel:
            messagebox.showinfo("Abu AI", "আগে একটা account সিলেক্ট করুন।")
            return None
        return self.accounts_list.get(sel[0])

    def change_password(self):
        uname = self._selected_username()
        if not uname:
            return
        pw = simpledialog.askstring("Password পাল্টান", f"'{uname}' এর নতুন Password:", parent=self.root, show="*")
        if not pw or len(pw) < 4:
            messagebox.showerror("Abu AI", "Password কমপক্ষে ৪ অক্ষরের হতে হবে।")
            return
        for u in srv.users_list:
            if u["username"] == uname:
                u["password_hash"] = srv.generate_password_hash(pw)
        srv.save_users(srv.users_list)
        messagebox.showinfo("Abu AI", "Password পাল্টানো হয়েছে।")

    def delete_account(self):
        uname = self._selected_username()
        if not uname:
            return
        if not messagebox.askyesno("Abu AI", f"'{uname}' account টা মুছে ফেলবেন?"):
            return
        srv.users_list[:] = [u for u in srv.users_list if u["username"] != uname]
        srv.save_users(srv.users_list)
        self.refresh_accounts()

    # ---------------- server ----------------
    def start_server(self):
        if not srv.users_list:
            messagebox.showwarning("Abu AI", "সার্ভার চালু করার আগে অন্তত ১টা account তৈরি করুন।")
            return
        self.server_thread = ServerThread()
        self.server_thread.start()
        self.start_btn.config(state="disabled", bg="#333", fg="#888")
        self.stop_btn.config(state="normal", bg="#a33", fg="white")
        self.status_label.config(text="● সার্ভার চলছে", fg="#4CAF50")

    def stop_server(self):
        if self.server_thread:
            self.server_thread.shutdown()
            self.server_thread = None
        self.start_btn.config(state="normal", bg="#4CAF50", fg="#08130a")
        self.stop_btn.config(state="disabled", bg="#333", fg="#888")
        self.status_label.config(text="● সার্ভার বন্ধ আছে", fg="#888")

    def copy_address(self):
        ip = srv.PC_LOCAL_IP if srv.PC_LOCAL_IP else "127.0.0.1"
        addr = f"http://{ip}:{srv.PORT}"
        self.root.clipboard_clear()
        self.root.clipboard_append(addr)
        messagebox.showinfo("Abu AI", f"Copied: {addr}")

    # ---------------- log ----------------
    def poll_log(self):
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", tk.END)
        for line in reversed(list(srv.activity_log)):
            self.log_text.insert(tk.END, line + "\n")
        self.log_text.config(state="disabled")
        self.root.after(2000, self.poll_log)

    def on_close(self):
        if self.server_thread:
            try:
                self.server_thread.shutdown()
            except Exception:
                pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    AbuAILauncher(root)
    root.mainloop()
