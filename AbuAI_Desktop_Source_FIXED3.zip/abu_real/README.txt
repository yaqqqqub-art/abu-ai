========================================
 Abu AI - Remote Control (PC + Phone)
========================================

WHAT'S IN THIS FOLDER
----------------------
  abu_ai_launcher.py     - RUN THIS ONE. Opens a proper window on the PC:
                            create/manage accounts, start/stop the server,
                            see the connect address, watch the activity log
  abu_robot_server.py    - the actual remote-control engine (Flask). The
                            launcher runs this for you - you don't need to
                            open it directly
  abu_apps.json           - starting list of apps for the "Apps" launcher
  build_exe.bat           - (Windows) turns abu_ai_launcher.py into a
                             double-click "Abu AI Desktop.exe", no Python
                             install needed afterwards
  start_abu_ai.bat        - keeps Abu AI running / auto-restarts if it crashes
  README.txt              - this file

ACCOUNTS ARE NOW PC-ONLY
---------------------------
Only the PC owner can create/change/delete accounts - and only from the
Abu AI Desktop window (or by opening http://localhost:5000/signup ON THE
PC itself). Phones on the Wi-Fi can Sign In with an account you gave them,
but can never create one themselves - if someone opens the address from
their phone and no account exists yet, they'll just see a message telling
them to ask the PC owner.

OPTION A - EASIEST: JUST RUN THE PYTHON VERSION
------------------------------------------------
1. Install Python from https://python.org if you don't have it
2. Open a terminal/CMD in this folder and run:
       pip install flask mss pillow pyautogui
3. Run:
       python abu_ai_launcher.py
4. The Abu AI Desktop window opens. Click "+ Add Account", set a Username
   + Password (up to 3 accounts total, one per phone/family member), then
   click "▶ Start Server".

OPTION B - NO PYTHON NEEDED: BUILD "Abu AI Desktop.exe"
---------------------------------------------------------
1. Install Python once, just to BUILD the exe (only needed this one time)
2. Double-click build_exe.bat  (or run it from CMD)
3. Wait for it to finish - your app is now at:
       dist\Abu AI Desktop.exe
4. Copy that .exe into its own folder and double-click it any time to run
   Abu AI - no Python needed anymore on this PC.

KEEPING IT ALWAYS RUNNING
---------------------------
Run start_abu_ai.bat instead of the exe directly - if Abu AI ever crashes
or you accidentally close it, this restarts it automatically.

To start it automatically every time you turn on your PC:
  1. Press Win + R, type:  shell:startup   and press Enter
  2. Put a SHORTCUT to start_abu_ai.bat into that folder

CONNECTING FROM YOUR PHONE
-----------------------------
1. Make sure your phone and PC are on the SAME Wi-Fi network
2. Open the Abu AI Desktop window on the PC - the connect address (e.g.
   http://192.168.1.207:5000) is shown right at the top; click
   "Copy Address" to copy it
3. On your phone's browser, go to that address and Sign In with the
   Username/Password the PC owner gave you
   (check "এই ডিভাইসে মনে রাখো" / Remember Me to stay signed in ~2 weeks)

If a "Windows Defender Firewall" popup appears the first time you start
the server, click "Allow access" - otherwise your phone won't be able to
find the PC.

WHAT'S NEW IN THIS VERSION (10 additions)
--------------------------------------------
 1. Abu AI Desktop - a real window on the PC (no more typing into a
    command prompt) for setting up accounts and running the server
 2. Accounts are PC-owner-only - phones can only Sign In, never
    self-register
 3. Add / remove accounts anytime from the Desktop window
 4. Change Password for any account from the Desktop window
 5. Start / Stop the server with one click (instead of closing the window)
 6. "Copy Address" button - copies http://<pc-ip>:5000 to the clipboard
 7. Live Activity Log inside the Desktop window (who connected, what they
    pressed) - not just on the web control page anymore
 8. Login lock-out - 5 wrong passwords in a row locks that username out
    for 60 seconds, to slow down guessing
 9. "Remember Me" checkbox on the phone's Sign In page - stay signed in
    for ~2 weeks on that phone instead of every single visit
10. The Sign In page now shows this PC's name + IP, a short feature list,
    and (on the abuai.com-style download website) a "Continue with
    Google" button - see the note below

WHAT'S NEW IN THIS UPDATE
--------------------------------------------
 1. FIXED: "Full Screen" button on the phone's control page - it opened
    fullscreen mode but the picture didn't actually grow to fill the
    phone's screen. Now it properly fills the screen (and tries to
    rotate to landscape) on Chrome/Android.
 2. Settings ("⋮" menu, top-right) added to BOTH apps:
      - Abu AI Desktop (PC): Language (Bangla/English/Japanese/German/
        Chinese/Russian - more of the app will be translated into these
        over time), "Ask me to Allow/Deny new phones" toggle, a Known
        Devices list (re-Allow a Blocked device or Block an Allowed
        one), and "Run Abu AI Desktop automatically when this PC
        starts" (Windows Startup-folder entry, can be turned back off
        any time from the same screen).
      - Abu AI Remote (phone's control page): the same Language picker,
        plus a "Stop / Disconnect" button - disconnects this phone, and
        if no other phone is connected, the PC's server automatically
        closes itself about a minute later (cancelled automatically if
        someone reconnects in that window).
 3. Connection requests: by default, the FIRST time a phone signs in
    with a valid Username/Password, the PC owner now gets an Allow/Deny
    popup on the Abu AI Desktop window showing the device's name before
    it can see/control the screen. Once Allowed, that device connects
    normally afterwards - unless later Blocked from Settings, in which
    case it needs to be Allowed again from Known Devices to reconnect.
    This can be turned off entirely from Settings if you don't want it.

ABOUT THE "CONTINUE WITH GOOGLE" BUTTON
-------------------------------------------
This is on the download WEBSITE (index.html), not the PC/phone Sign In
page - real accounts on the PC still use Abu AI's own Username/Password.
Actual Google Sign-In needs a free Client ID from YOUR OWN Google Cloud
Console account (Anthropic/Claude can't create one on your behalf) - the
button is wired up with Google's official script and a placeholder ID; see
the comment right above it in index.html for the 2-minute setup step.

SECURITY NOTE
---------------
Abu AI only works on your local Wi-Fi network. Anyone with a valid
username/password on that network can control this PC, so don't share
your login with people you don't trust, and don't try to expose this
to the open internet.
