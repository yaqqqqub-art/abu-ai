@echo off
REM ============================================================
REM  Keeps Abu AI running "forever": if it ever crashes or you
REM  accidentally close its window, this restarts it automatically.
REM
REM  To make Abu AI start automatically every time you turn on
REM  your PC:
REM    1. Press Win + R, type: shell:startup   and press Enter
REM    2. Copy a SHORTCUT to this file into that folder
REM ============================================================

cd /d "%~dp0"

:loop
echo Starting Abu AI ...
if exist "Abu AI Desktop.exe" (
    "Abu AI Desktop.exe"
) else (
    python abu_ai_launcher.py
)
echo.
echo Abu AI stopped - restarting in 3 seconds (close this window to stop for good)...
timeout /t 3 >nul
goto loop
