"""
Abu AI Desktop - Launcher (GUI)
----------------------------------------------------
Run THIS file (or its .exe build) instead of typing anything into a
command prompt. It opens a proper window on the PC where you:

  - Create the first Abu AI account (Username + Password)
  - Add / change-password / delete accounts (up to 3), all from the PC
    itself - phones on the Wi-Fi can only Sign In, never create accounts
  - See this computer's name + local IP (the address phones need to type)
    - click it to open it straight in your browser
    - or tap "QR Code" and scan it with the phone's camera instead of typing
  - Start / Stop / Restart the Abu AI server with one click
    - the logo's face turns sad when the server is off, and happy when
      it's running, with a message explaining what to do
  - See Control: a live list of which phones are connected right now,
    their nickname, battery %, and a small preview of their screen
  - File Transfer: send a file from this PC so any connected phone can
    download it, and browse/open the files phones have sent you
  - Watch a live log of who connected and what they did
  - Copy the connect address to the clipboard in one click

Requirements: same as abu_robot_server.py (Pillow is already a
dependency of that file), plus nothing extra - Tkinter ships with a
normal Python install on Windows/Mac. Just run:
    python abu_ai_launcher.py

Optional: `pip install qrcode` to enable the "QR Code" button. If it
isn't installed, that button still works, it just explains how to add it.
"""

import io
import os
import sys
import shutil
import platform
import subprocess
import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox, filedialog

from PIL import Image, ImageDraw, ImageFont, ImageTk

import abu_robot_server as srv          # the actual Flask server + all its state
from werkzeug.serving import make_server

try:
    import requests
    REQUESTS_AVAILABLE = True
except Exception:
    requests = None
    REQUESTS_AVAILABLE = False

try:
    import qrcode
    QRCODE_AVAILABLE = True
except Exception:
    qrcode = None
    QRCODE_AVAILABLE = False

# If build_exe.bat was used with the bundled .ico, this file sits next to
# the script/.exe - used for the sharpest possible taskbar/window icon on
# Windows. Safe to be missing (see build_app_icon_image() fallback below).
ICON_FILE = os.path.join(
    os.path.dirname(sys.executable) if getattr(sys, 'frozen', False)
    else os.path.dirname(os.path.abspath(__file__)),
    "abu_ai_icon.ico",
)


# ---------------------------------------------------------
# A real start/stop-able server (app.run() alone can't be stopped cleanly)
# ---------------------------------------------------------
class ServerThread(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._srv = make_server('0.0.0.0', srv.PORT, srv.app, threaded=True)

    def run(self):
        self._srv.serve_forever()

    def shutdown(self):
        self._srv.shutdown()


# ---------------------------------------------------------
# Build the "A" badge as a real image, so it can be used both as the
# window/taskbar icon (instead of the default Python icon) and as the
# little animated face drawn on the main window.
# ---------------------------------------------------------
def _load_logo_font(size):
    for name in ("arialbd.ttf", "DejaVuSans-Bold.ttf", "Arial Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    return ImageFont.load_default()


def build_app_icon_image(size=128):
    """Green-ring 'A' badge with a little antenna - used as the app icon."""
    img = Image.new("RGBA", (size, size), (13, 13, 13, 255))
    d = ImageDraw.Draw(img)
    pad = max(4, size // 20)
    d.ellipse([pad, pad, size - pad, size - pad],
              outline=(76, 175, 80, 255), width=max(3, size // 22), fill=(19, 42, 23, 255))
    ax, ay = size / 2, pad * 0.9
    d.ellipse([ax - size * 0.035, ay - size * 0.035, ax + size * 0.035, ay + size * 0.035],
              fill=(76, 175, 80, 255))
    d.line([ax, ay + size * 0.035, ax, ay + size * 0.12], fill=(76, 175, 80, 255), width=max(2, size // 40))
    font = _load_logo_font(int(size * 0.4))
    d.text((size / 2, size / 2 + size * 0.06), "A", fill=(76, 175, 80, 255), font=font, anchor="mm")
    return img


def _startup_folder():
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")


_AUTOSTART_BAT_NAME = "AbuAI_AutoStart.bat"


def set_windows_autostart(enable):
    """Adds/removes a small .bat file in the Windows Startup folder so Abu
    AI Desktop launches automatically when the PC turns on - and can be
    turned back off any time from Settings. Returns (ok: bool, message: str)."""
    if platform.system() != "Windows":
        return False, ("Auto-start automation is only built for Windows right now. "
                        "On Mac/Linux, add this app to your OS's own Login Items / "
                        "Startup Applications list manually.")
    folder = _startup_folder()
    if not folder:
        return False, "Windows-এর Startup folder খুঁজে পাওয়া যায়নি (APPDATA missing)।"
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception as e:
        return False, f"Startup folder তৈরি করা যায়নি: {e}"
    bat_path = os.path.join(folder, _AUTOSTART_BAT_NAME)
    if enable:
        if getattr(sys, 'frozen', False):
            target = f'start "" "{sys.executable}"'
        else:
            this_file = os.path.abspath(__file__)
            pyw = shutil.which("pythonw") or shutil.which("python")
            target = f'start "" "{pyw}" "{this_file}"' if pyw else f'start "" python "{this_file}"'
        try:
            with open(bat_path, "w", encoding="utf-8") as f:
                f.write("@echo off\r\n" + target + "\r\n")
            return True, "এখন থেকে PC চালু হলেই Abu AI Desktop নিজে থেকে চালু হবে।"
        except Exception as e:
            return False, f"Startup entry তৈরি করা যায়নি: {e}"
    else:
        try:
            if os.path.exists(bat_path):
                os.remove(bat_path)
            return True, "Auto-start বন্ধ করা হয়েছে - এখন থেকে PC চালু হলে Abu AI নিজে থেকে খুলবে না।"
        except Exception as e:
            return False, f"Auto-start entry মুছতে সমস্যা হয়েছে: {e}"


class RemoteClient:
    """Talks to ANOTHER PC that's running Abu AI (abu_robot_server.py),
    so this PC can control that one - same idea as a phone controlling
    this PC, just PC-to-PC. Every method returns (ok: bool, message: str)."""

    def __init__(self):
        self.session = requests.Session() if REQUESTS_AVAILABLE else None
        self.base_url = None
        self.connected = False
        self.pc_name = None
        self._move_lock = threading.Lock()
        self._move_in_flight = False
        self._pending_dx = 0
        self._pending_dy = 0

    def connect(self, ip, port, username, password, timeout=6):
        if not REQUESTS_AVAILABLE:
            return False, "'requests' package ইনস্টল নেই। Terminal-এ চালান: pip install requests"
        ip = (ip or "").strip()
        port = (port or "").strip() or "5000"
        if not ip:
            return False, "PC-এর IP address দিন।"
        base = f"http://{ip}:{port}"
        try:
            r = self.session.post(f"{base}/login",
                                   data={"username": username, "password": password},
                                   timeout=timeout)
        except Exception as e:
            return False, f"Connect করা যায়নি: {e}"
        # login() redirects to '/' (the control page) on success, or
        # re-renders the login page (with an error message) on failure.
        if r.status_code == 200 and ("id=\"screen\"" in r.text or "Sign Out" in r.text or "/api/heartbeat" in r.text):
            self.base_url = base
            self.connected = True
            try:
                info = self.session.get(f"{base}/api/pc_info", timeout=timeout).json()
                self.pc_name = info.get("name") or ip
            except Exception:
                self.pc_name = ip
            return True, f"'{self.pc_name}' এর সাথে connected।"
        return False, "ভুল Username/Password অথবা PC-তে Abu AI সার্ভার চালু নেই।"

    def disconnect(self):
        self.connected = False
        self.base_url = None
        self.pc_name = None
        if REQUESTS_AVAILABLE:
            self.session = requests.Session()

    def _post(self, path, payload=None):
        if not self.connected:
            return False
        try:
            self.session.post(f"{self.base_url}{path}", json=payload or {}, timeout=4)
            return True
        except Exception:
            return False

    # ---- mouse ----
    def move_relative(self, dx, dy):
        """Coalescing sender (same idea as the phone trackpad): only one
        move request in flight at a time, so a burst of drag events on a
        slow/laggy connection doesn't pile up and make the pointer jitter."""
        with self._move_lock:
            self._pending_dx += dx
            self._pending_dy += dy
            if self._move_in_flight:
                return
            self._move_in_flight = True
            dx, dy = self._pending_dx, self._pending_dy
            self._pending_dx = self._pending_dy = 0

        def worker():
            self._post("/api/mouse_move", {"dx": dx, "dy": dy})
            with self._move_lock:
                self._move_in_flight = False
                more_dx, more_dy = self._pending_dx, self._pending_dy
                self._pending_dx = self._pending_dy = 0
            if more_dx or more_dy:
                self.move_relative(more_dx, more_dy)

        threading.Thread(target=worker, daemon=True).start()

    def click(self, button="left"):
        threading.Thread(target=self._post, args=("/api/click", {"button": button}), daemon=True).start()

    def double_click(self, button="left"):
        threading.Thread(target=self._post, args=("/api/doubleclick", {"button": button}), daemon=True).start()

    def mouse_down(self, button="left"):
        threading.Thread(target=self._post, args=("/api/mouse_down", {"button": button}), daemon=True).start()

    def mouse_up(self, button="left"):
        threading.Thread(target=self._post, args=("/api/mouse_up", {"button": button}), daemon=True).start()

    def scroll(self, amount):
        threading.Thread(target=self._post, args=("/api/scroll", {"amount": amount}), daemon=True).start()

    # ---- keyboard ----
    def type_text(self, text):
        threading.Thread(target=self._post, args=("/api/type", {"text": text}), daemon=True).start()

    def send_shortcut(self, combo):
        keys = [k.strip().lower() for k in combo.split("+") if k.strip()]
        if not keys:
            return
        threading.Thread(target=self._post, args=("/api/press", {"keys": keys}), daemon=True).start()


class AbuAILauncher:
    def __init__(self, root):
        self.root = root
        self.server_thread = None
        root.title("Abu AI Desktop")
        root.configure(bg="#0d0d0d")
        root.geometry("460x760")
        root.minsize(420, 640)

        # ---------- custom window/taskbar icon (no more default Python icon) ----------
        # Prefer the bundled .ico (sharper on Windows, and what build_exe.bat now
        # embeds into the .exe itself). Falls back to the icon drawn in code.
        try:
            if os.path.isfile(ICON_FILE):
                root.iconbitmap(default=ICON_FILE)
        except Exception:
            pass
        try:
            self._icon_photo = ImageTk.PhotoImage(build_app_icon_image(128))
            root.iconphoto(True, self._icon_photo)
        except Exception:
            pass  # icon is cosmetic - never let it block the app from opening

        # ---------- header (canvas logo with a face that reacts to server state) ----------
        header = tk.Frame(root, bg="#0d0d0d")
        header.pack(pady=(18, 6), fill="x")
        menu_row = tk.Frame(header, bg="#0d0d0d")
        menu_row.pack(fill="x")
        tk.Button(menu_row, text="⋮", command=self.open_settings, bg="#0d0d0d", fg="#eee",
                  relief="flat", font=("Arial", 16), bd=0, activebackground="#0d0d0d").pack(side="right", padx=12)
        self.logo = tk.Canvas(header, width=64, height=64, bg="#0d0d0d", highlightthickness=0)
        self.logo.pack()
        tk.Label(header, text="Abu AI Desktop", fg="#eef1ec", bg="#0d0d0d",
                 font=("Arial", 18, "bold")).pack(pady=(6, 0))
        tk.Label(header, text="PC থেকে account সেট করুন, তারপর সার্ভার চালু করুন",
                 fg="#888", bg="#0d0d0d", font=("Arial", 10)).pack()

        # ---------- this computer's identity ----------
        pc_box = tk.Frame(root, bg="#141414")
        pc_box.pack(fill="x", padx=18, pady=10)
        ip_text = srv.PC_LOCAL_IP if srv.PC_LOCAL_IP else "IP not available"
        tk.Label(pc_box, text=f"এই PC: {srv.PC_NAME}", fg="#eee", bg="#141414",
                 font=("Arial", 10, "bold")).pack(anchor="w", padx=10, pady=(8, 0))

        self.addr_label = tk.Label(pc_box, text=f"Address (ফোনে লিখুন): http://{ip_text}:{srv.PORT}",
                                    fg="#8fd18f", bg="#141414", font=("Consolas", 10, "underline"),
                                    cursor="hand2")
        self.addr_label.pack(anchor="w", padx=10, pady=(0, 0))
        self.addr_label.bind("<Button-1>", lambda e: self.open_address_in_browser())
        tk.Label(pc_box, text="(ক্লিক করলে ব্রাউজারে খুলবে)", fg="#666", bg="#141414",
                 font=("Arial", 8)).pack(anchor="w", padx=10, pady=(0, 8))

        pc_btns = tk.Frame(pc_box, bg="#141414")
        pc_btns.pack(fill="x", padx=10, pady=(0, 8))
        tk.Button(pc_btns, text="Copy Address", command=self.copy_address,
                  bg="#333", fg="#eee", relief="flat").pack(side="right")
        tk.Button(pc_btns, text="📷 QR Code", command=self.open_qr_view,
                  bg="#555", fg="#eee", relief="flat").pack(side="right", padx=(0, 6))
        tk.Button(pc_btns, text="👁 See Control", command=self.open_control_view,
                  bg="#2196F3", fg="white", relief="flat").pack(side="right", padx=(0, 6))

        # ---------- file transfer (send-to-phone / phone-uploads) ----------
        tk.Button(root, text="📁 File Transfer (Send to Phone / Phone Uploads)",
                  command=self.open_file_transfer,
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(fill="x", padx=18, pady=(0, 10), ipady=4)

        # ---------- control another PC (this PC acting as a remote) ----------
        tk.Button(root, text="🖥️ Control Another PC",
                  command=self.open_remote_control,
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(fill="x", padx=18, pady=(0, 10), ipady=4)

        # ---------- accounts ----------
        acc_label_row = tk.Frame(root, bg="#0d0d0d")
        acc_label_row.pack(fill="x", padx=18, pady=(4, 2))
        tk.Label(acc_label_row, text="Accounts (সর্বোচ্চ ৩টা)", fg="#eee", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(side="left")
        self.slots_label = tk.Label(acc_label_row, text="", fg="#888", bg="#0d0d0d", font=("Arial", 9))
        self.slots_label.pack(side="right")

        self.accounts_list = tk.Listbox(root, height=4, bg="#141414", fg="#eee",
                                         selectbackground="#4CAF50", relief="flat", highlightthickness=0)
        self.accounts_list.pack(fill="x", padx=18)

        acc_btns = tk.Frame(root, bg="#0d0d0d")
        acc_btns.pack(fill="x", padx=18, pady=8)
        tk.Button(acc_btns, text="+ Add Account", command=self.add_account,
                  bg="#4CAF50", fg="#08130a", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 4))
        tk.Button(acc_btns, text="Change Password", command=self.change_password,
                  bg="#2196F3", fg="white", relief="flat").pack(side="left", expand=True, fill="x", padx=4)
        tk.Button(acc_btns, text="Delete", command=self.delete_account,
                  bg="#a33", fg="white", relief="flat").pack(side="left", expand=True, fill="x", padx=(4, 0))

        # ---------- server controls ----------
        srv_box = tk.Frame(root, bg="#0d0d0d")
        srv_box.pack(fill="x", padx=18, pady=(10, 4))
        self.start_btn = tk.Button(srv_box, text="▶ Start Server", command=self.start_server,
                                    bg="#4CAF50", fg="#08130a", font=("Arial", 12, "bold"), relief="flat")
        self.start_btn.pack(side="left", expand=True, fill="x", padx=(0, 4), ipady=6)
        self.stop_btn = tk.Button(srv_box, text="■ Stop Server", command=self.stop_server,
                                   bg="#333", fg="#888", font=("Arial", 12, "bold"), relief="flat", state="disabled")
        self.stop_btn.pack(side="left", expand=True, fill="x", padx=(4, 4), ipady=6)
        self.restart_btn = tk.Button(srv_box, text="🔁 Restart", command=self.restart_server,
                                      bg="#333", fg="#888", font=("Arial", 12, "bold"), relief="flat", state="disabled")
        self.restart_btn.pack(side="left", expand=True, fill="x", padx=(4, 0), ipady=6)

        self.status_label = tk.Label(root, text="● সার্ভার বন্ধ আছে", fg="#888", bg="#0d0d0d", font=("Arial", 10))
        self.status_label.pack(pady=(2, 2))

        # the logo's little "speech" message - sad when off, happy when running
        self.face_msg = tk.Label(root, text="", fg="#d8b84a", bg="#0d0d0d", font=("Arial", 9),
                                  wraplength=420, justify="center")
        self.face_msg.pack(pady=(0, 8), padx=18)

        # ---------- activity log ----------
        tk.Label(root, text="Activity Log", fg="#eee", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=18)
        self.log_text = tk.Text(root, height=7, bg="#141414", fg="#8fd18f", relief="flat",
                                 highlightthickness=0, font=("Consolas", 9), state="disabled")
        self.log_text.pack(fill="both", expand=True, padx=18, pady=(4, 10))

        # ---------- features footer ----------
        tk.Label(root, text="Screen • Touchpad • Apps launcher • File transfer • Game controller — up to 3 phones",
                 fg="#666", bg="#0d0d0d", font=("Arial", 8), wraplength=420).pack(pady=(0, 10))

        # ---------- Settings state (Language / connect-approval / auto-start) ----------
        self._shown_approval_ids = set()
        srv.on_auto_stop_server = lambda: self.root.after(0, self.stop_server)

        self.set_face("stopped")   # server starts off, so the face starts sad
        self.refresh_accounts()
        self.poll_log()
        self.poll_approvals()
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------- Settings (⋮ menu): Language, connect-approval, auto-start ----------------
    def open_settings(self):
        win = tk.Toplevel(self.root)
        win.title("Settings")
        win.configure(bg="#0d0d0d")
        win.geometry("380x560")
        win.minsize(340, 460)

        tk.Label(win, text="⚙ Settings", fg="#eef1ec", bg="#0d0d0d",
                 font=("Arial", 14, "bold")).pack(pady=(16, 10))

        # ---- Language ----
        tk.Label(win, text="Language", fg="#8fd18f", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=18)
        lang_var = tk.StringVar(value=srv.app_settings.get("language", "bn"))
        lang_names = list(srv.SUPPORTED_LANGUAGES.values())
        lang_codes = list(srv.SUPPORTED_LANGUAGES.keys())
        lang_box = ttk.Combobox(win, values=lang_names, state="readonly")
        lang_box.set(srv.SUPPORTED_LANGUAGES.get(lang_var.get(), lang_names[0]))
        lang_box.pack(fill="x", padx=18, pady=(4, 2))

        def on_lang_change(event=None):
            idx = lang_names.index(lang_box.get())
            srv.app_settings["language"] = lang_codes[idx]
            srv.save_settings()

        lang_box.bind("<<ComboboxSelected>>", on_lang_change)
        tk.Label(win, text="6 languages available: Bangla, English, Japanese, German,\n"
                            "Chinese, Russian. Full app translation is coming later -\n"
                            "for now this is saved as your preferred language.",
                 fg="#888", bg="#0d0d0d", font=("Arial", 8), justify="left",
                 wraplength=340).pack(anchor="w", padx=18, pady=(0, 12))

        # ---- Connection requests / approval ----
        tk.Label(win, text="Connection Requests", fg="#8fd18f", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=18)

        approve_var = tk.BooleanVar(value=srv.app_settings.get("require_approval", True))

        def on_approve_toggle():
            srv.app_settings["require_approval"] = approve_var.get()
            srv.save_settings()

        tk.Checkbutton(win, text="Ask me to Allow/Deny before a new phone can connect & see the screen",
                        variable=approve_var, command=on_approve_toggle,
                        bg="#0d0d0d", fg="#eee", selectcolor="#141414", activebackground="#0d0d0d",
                        activeforeground="#eee", wraplength=340, justify="left", anchor="w"
                        ).pack(fill="x", padx=14, pady=(4, 10))

        # ---- Known devices (re-Allow a previously Blocked one, or Block one) ----
        tk.Label(win, text="Known Devices", fg="#8fd18f", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=18)
        devices_frame = tk.Frame(win, bg="#0d0d0d")
        devices_frame.pack(fill="x", padx=14, pady=(4, 10))

        def render_devices():
            for w in devices_frame.winfo_children():
                w.destroy()
            if not srv.device_status:
                tk.Label(devices_frame, text="(কোনো ডিভাইস এখনো নেই / no devices yet)",
                         fg="#666", bg="#0d0d0d", font=("Arial", 9)).pack(anchor="w")
                return
            for uname, status in sorted(srv.device_status.items()):
                row = tk.Frame(devices_frame, bg="#141414")
                row.pack(fill="x", pady=2, ipady=4)
                color = "#8fd18f" if status == "approved" else "#ff6b6b"
                tk.Label(row, text=f"{uname} — {status}", fg=color, bg="#141414",
                         font=("Arial", 9)).pack(side="left", padx=8)
                if status == "approved":
                    tk.Button(row, text="Block", bg="#a33", fg="white", relief="flat",
                              command=lambda u=uname: (srv.set_device_status(u, "blocked"), render_devices())
                              ).pack(side="right", padx=6)
                else:
                    tk.Button(row, text="Allow", bg="#4CAF50", fg="#08130a", relief="flat",
                              command=lambda u=uname: (srv.set_device_status(u, "approved"), render_devices())
                              ).pack(side="right", padx=6)

        render_devices()

        # ---- Run automatically when PC starts ----
        tk.Label(win, text="Startup", fg="#8fd18f", bg="#0d0d0d",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=18)
        autostart_var = tk.BooleanVar(value=srv.app_settings.get("auto_start", False))

        def on_autostart_toggle():
            enabled = autostart_var.get()
            ok, msg = set_windows_autostart(enabled)
            if not ok:
                autostart_var.set(not enabled)  # revert the checkbox
                messagebox.showwarning("Abu AI", msg)
                return
            srv.app_settings["auto_start"] = enabled
            srv.save_settings()
            if msg:
                messagebox.showinfo("Abu AI", msg)

        tk.Checkbutton(win, text="Run Abu AI Desktop automatically when this PC starts",
                        variable=autostart_var, command=on_autostart_toggle,
                        bg="#0d0d0d", fg="#eee", selectcolor="#141414", activebackground="#0d0d0d",
                        activeforeground="#eee", wraplength=340, justify="left", anchor="w"
                        ).pack(fill="x", padx=14, pady=(4, 6))
        tk.Label(win, text="You can always turn this back off from here whenever you want.",
                 fg="#666", bg="#0d0d0d", font=("Arial", 8), wraplength=340,
                 justify="left").pack(anchor="w", padx=18, pady=(0, 14))

    # ---------------- pending connect-request popups (Allow/Deny) ----------------
    def poll_approvals(self):
        for req_id, entry in list(srv.pending_approvals.items()):
            if entry.get("status") != "pending" or req_id in self._shown_approval_ids:
                continue
            self._shown_approval_ids.add(req_id)
            name = entry.get("device_name", "Unknown device")
            uname = entry.get("username", "")
            allow = messagebox.askyesno(
                "Abu AI - Connection Request",
                f"'{name}' (account: {uname}) wants to connect to this PC and view/control your "
                f"screen.\n\nDo you want to Allow it?")
            entry["status"] = "approved" if allow else "denied"
            srv.set_device_status(uname, "approved" if allow else "blocked")
        self.root.after(1000, self.poll_approvals)

    # ---------------- logo face ----------------
    def set_face(self, state):
        """state: 'stopped' (sad), 'running' (happy)."""
        c = self.logo
        c.delete("all")
        c.create_oval(3, 3, 61, 61, outline="#4CAF50", width=3, fill="#132a17")
        # antenna, matching the web page's badge
        c.create_oval(29, 4, 35, 10, fill="#4CAF50", outline="")
        c.create_line(32, 10, 32, 16, fill="#4CAF50", width=2)
        # eyes
        c.create_oval(20, 26, 25, 31, fill="#4CAF50", outline="")
        c.create_oval(39, 26, 44, 31, fill="#4CAF50", outline="")
        # mouth: sad arc when stopped, happy arc when running
        if state == "running":
            c.create_arc(20, 30, 44, 48, start=200, extent=140, style="arc",
                         outline="#4CAF50", width=2)
            self.status_label.config(text="● সার্ভার চলছে", fg="#4CAF50")
            self.face_msg.config(
                fg="#8fd18f",
                text="🙂 সার্ভার চালু আছে! ফোনে ঠিকানাটি ব্রাউজারে লিখুন অথবা উপরের address-এ ক্লিক করুন।")
        else:
            c.create_arc(20, 38, 44, 56, start=20, extent=140, style="arc",
                         outline="#4CAF50", width=2)
            self.status_label.config(text="● সার্ভার বন্ধ আছে", fg="#888")
            self.face_msg.config(
                fg="#d8b84a",
                text="😔 দুঃখিত, সার্ভার বন্ধ (down) আছে। চালু করতে উপরের 'Start Server' বাটনে চাপুন।\n"
                     "Sorry, the server is closed and down — press Start Server to start it.")

    # ---------------- address ----------------
    def _current_address(self):
        ip = srv.PC_LOCAL_IP if srv.PC_LOCAL_IP else "127.0.0.1"
        return f"http://{ip}:{srv.PORT}"

    def open_address_in_browser(self):
        webbrowser.open(self._current_address())

    # ---------------- QR code (feature #1 added on top of the request) ----------------
    def open_qr_view(self):
        win = tk.Toplevel(self.root)
        win.title("QR Code - Abu AI")
        win.configure(bg="#0d0d0d")
        win.geometry("320x400")
        win.resizable(False, False)

        addr = self._current_address()
        tk.Label(win, text="ফোনের ক্যামেরা দিয়ে স্ক্যান করুন", fg="#eee", bg="#0d0d0d",
                 font=("Arial", 12, "bold")).pack(pady=(18, 4))

        if QRCODE_AVAILABLE:
            try:
                qr = qrcode.QRCode(border=1, box_size=8)
                qr.add_data(addr)
                qr.make(fit=True)
                qr_img = qr.make_image(fill_color="#4CAF50", back_color="#0d0d0d").convert("RGB")
                photo = ImageTk.PhotoImage(qr_img)
                lbl = tk.Label(win, image=photo, bg="#0d0d0d")
                lbl.image = photo  # keep a reference
                lbl.pack(pady=6)
            except Exception as e:
                tk.Label(win, text=f"QR তৈরি করা যায়নি: {e}", fg="#ff6b6b", bg="#0d0d0d",
                         font=("Arial", 9), wraplength=280).pack(pady=20)
        else:
            tk.Label(win, text="QR code দেখতে হলে প্রথমে ইনস্টল করুন:",
                     fg="#d8b84a", bg="#0d0d0d", font=("Arial", 9), wraplength=280).pack(pady=(10, 4))
            tk.Label(win, text="pip install qrcode", fg="#8fd18f", bg="#141414",
                     font=("Consolas", 10)).pack(pady=4, ipadx=10, ipady=4)
            tk.Label(win, text="তারপর Abu AI Desktop আবার চালু করুন।", fg="#888", bg="#0d0d0d",
                     font=("Arial", 9)).pack(pady=(0, 10))

        tk.Label(win, text=addr, fg="#8fd18f", bg="#0d0d0d", font=("Consolas", 10)).pack(pady=(6, 16))

    # ---------------- accounts ----------------
    def refresh_accounts(self):
        self.accounts_list.delete(0, tk.END)
        for u in srv.users_list:
            self.accounts_list.insert(tk.END, u["username"])
        self.slots_label.config(text=f"{len(srv.users_list)}/{srv.MAX_CONTROLLERS} ব্যবহৃত")

    def add_account(self):
        if len(srv.users_list) >= srv.MAX_CONTROLLERS:
            messagebox.showinfo("Abu AI", "সর্বোচ্চ ৩টা account হয়ে গেছে।")
            return
        uname = simpledialog.askstring("নতুন Account", "Username:", parent=self.root)
        if not uname:
            return
        uname = uname.strip()
        if not uname:
            return
        if any(u["username"] == uname for u in srv.users_list):
            messagebox.showerror("Abu AI", "এই নামে আগে থেকেই একটা account আছে।")
            return
        pw = simpledialog.askstring("Password", "Password (কমপক্ষে ৪ অক্ষর):", parent=self.root, show="*")
        if not pw or len(pw) < 4:
            messagebox.showerror("Abu AI", "Password কমপক্ষে ৪ অক্ষরের হতে হবে।")
            return
        srv.users_list.append({"username": uname, "password_hash": srv.generate_password_hash(pw)})
        srv.save_users(srv.users_list)
        self.refresh_accounts()
        messagebox.showinfo("Abu AI", f"'{uname}' account তৈরি হয়েছে।")

    def _selected_username(self):
        sel = self.accounts_list.curselection()
        if not sel:
            messagebox.showinfo("Abu AI", "আগে একটা account সিলেক্ট করুন।")
            return None
        return self.accounts_list.get(sel[0])

    def change_password(self):
        uname = self._selected_username()
        if not uname:
            return
        pw = simpledialog.askstring("Password পাল্টান", f"'{uname}' এর নতুন Password:", parent=self.root, show="*")
        if not pw or len(pw) < 4:
            messagebox.showerror("Abu AI", "Password কমপক্ষে ৪ অক্ষরের হতে হবে।")
            return
        for u in srv.users_list:
            if u["username"] == uname:
                u["password_hash"] = srv.generate_password_hash(pw)
        srv.save_users(srv.users_list)
        messagebox.showinfo("Abu AI", "Password পাল্টানো হয়েছে।")

    def delete_account(self):
        uname = self._selected_username()
        if not uname:
            return
        if not messagebox.askyesno("Abu AI", f"'{uname}' account টা মুছে ফেলবেন?"):
            return
        srv.users_list[:] = [u for u in srv.users_list if u["username"] != uname]
        srv.save_users(srv.users_list)
        self.refresh_accounts()

    # ---------------- server ----------------
    def start_server(self):
        if not srv.users_list:
            messagebox.showwarning("Abu AI", "সার্ভার চালু করার আগে অন্তত ১টা account তৈরি করুন।")
            return
        self.server_thread = ServerThread()
        self.server_thread.start()
        self.start_btn.config(state="disabled", bg="#333", fg="#888")
        self.stop_btn.config(state="normal", bg="#a33", fg="white")
        self.restart_btn.config(state="normal", bg="#2196F3", fg="white")
        self.set_face("running")

    def stop_server(self):
        if self.server_thread:
            self.server_thread.shutdown()
            self.server_thread = None
        self.start_btn.config(state="normal", bg="#4CAF50", fg="#08130a")
        self.stop_btn.config(state="disabled", bg="#333", fg="#888")
        self.restart_btn.config(state="disabled", bg="#333", fg="#888")
        self.set_face("stopped")

    def restart_server(self):
        """Feature #2 added on top of the request: one click instead of Stop
        then Start - handy after adding an account or app while already running."""
        if self.server_thread:
            self.stop_server()
        self.start_server()

    def copy_address(self):
        addr = self._current_address()
        self.root.clipboard_clear()
        self.root.clipboard_append(addr)
        messagebox.showinfo("Abu AI", f"Copied: {addr}")

    # ---------------- File Transfer (Send to Phone / Phone Uploads) ----------------
    def open_file_transfer(self):
        win = tk.Toplevel(self.root)
        win.title("File Transfer - Abu AI")
        win.configure(bg="#0d0d0d")
        win.geometry("420x560")
        win.minsize(380, 460)

        tk.Label(win, text="📁 File Transfer", fg="#eef1ec", bg="#0d0d0d",
                 font=("Arial", 14, "bold")).pack(pady=(16, 10))

        # ---- Send to Phone ----
        send_box = tk.LabelFrame(win, text=" 📤 Send to Phone ", fg="#eee", bg="#141414",
                                  labelanchor="nw", bd=1, font=("Arial", 9, "bold"))
        send_box.pack(fill="x", padx=16, pady=(0, 10))
        tk.Label(send_box, text="এখানে যোগ করা ফাইল যেকোনো connected ফোন download করতে পারবে (ফোনে Files/Session চালু থাকতে হবে)।",
                 fg="#888", bg="#141414", font=("Arial", 8), wraplength=370, justify="left").pack(anchor="w", padx=8, pady=(8, 6))

        shared_list = tk.Listbox(send_box, height=5, bg="#0e100d", fg="#eee", relief="flat", highlightthickness=0)
        shared_list.pack(fill="x", padx=8, pady=(0, 6))

        def refresh_shared():
            shared_list.delete(0, tk.END)
            try:
                for name in sorted(os.listdir(srv.PC_SHARE_DIR)):
                    if os.path.isfile(os.path.join(srv.PC_SHARE_DIR, name)):
                        shared_list.insert(tk.END, name)
            except OSError:
                pass

        def choose_and_send():
            path = filedialog.askopenfilename(title="ফোনে পাঠানোর জন্য ফাইল বাছাই করুন")
            if not path:
                return
            try:
                dest = os.path.join(srv.PC_SHARE_DIR, os.path.basename(path))
                shutil.copy2(path, dest)
                refresh_shared()
                messagebox.showinfo("Abu AI", f"'{os.path.basename(path)}' পাঠানোর জন্য প্রস্তুত। ফোনের Files panel থেকে download করা যাবে।")
            except Exception as e:
                messagebox.showerror("Abu AI", f"পাঠানো যায়নি: {e}")

        def remove_shared():
            sel = shared_list.curselection()
            if not sel:
                messagebox.showinfo("Abu AI", "আগে একটা ফাইল সিলেক্ট করুন।")
                return
            name = shared_list.get(sel[0])
            try:
                os.remove(os.path.join(srv.PC_SHARE_DIR, name))
                refresh_shared()
            except OSError as e:
                messagebox.showerror("Abu AI", str(e))

        send_btn_row = tk.Frame(send_box, bg="#141414")
        send_btn_row.pack(fill="x", padx=8, pady=(0, 8))
        tk.Button(send_btn_row, text="+ ফাইল বাছাই করে পাঠান", command=choose_and_send,
                  bg="#4CAF50", fg="#08130a", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 4))
        tk.Button(send_btn_row, text="Remove", command=remove_shared,
                  bg="#a33", fg="white", relief="flat").pack(side="left", padx=(4, 0))

        # ---- Phone Uploads ----
        up_box = tk.LabelFrame(win, text=" 📥 Phone Uploads (ফোন থেকে আসা ফাইল) ", fg="#eee", bg="#141414",
                                labelanchor="nw", bd=1, font=("Arial", 9, "bold"))
        up_box.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        up_list = tk.Listbox(up_box, height=8, bg="#0e100d", fg="#eee", relief="flat", highlightthickness=0)
        up_list.pack(fill="both", expand=True, padx=8, pady=(8, 6))

        def refresh_uploads():
            up_list.delete(0, tk.END)
            for slot in range(1, srv.MAX_CONTROLLERS + 1):
                folder = os.path.join(srv.PHONE_UPLOAD_DIR, f"controller{slot}")
                if os.path.isdir(folder):
                    for name in sorted(os.listdir(folder)):
                        if os.path.isfile(os.path.join(folder, name)):
                            up_list.insert(tk.END, f"[Controller {slot}] {name}")

        def open_uploads_folder():
            try:
                if sys.platform.startswith("win"):
                    os.startfile(srv.PHONE_UPLOAD_DIR)
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", srv.PHONE_UPLOAD_DIR])
                else:
                    subprocess.Popen(["xdg-open", srv.PHONE_UPLOAD_DIR])
            except Exception as e:
                messagebox.showerror("Abu AI", str(e))

        up_btn_row = tk.Frame(up_box, bg="#141414")
        up_btn_row.pack(fill="x", padx=8, pady=(0, 8))
        tk.Button(up_btn_row, text="🔄 Refresh", command=refresh_uploads,
                  bg="#2196F3", fg="white", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 4))
        tk.Button(up_btn_row, text="📂 Open Folder", command=open_uploads_folder,
                  bg="#333", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(4, 0))

        refresh_shared()
        refresh_uploads()

    # ---------------- Control Another PC (this PC as a remote-control client) ----------------
    def open_remote_control(self):
        win = tk.Toplevel(self.root)
        win.title("Control Another PC - Abu AI")
        win.configure(bg="#0d0d0d")
        win.geometry("400x620")
        win.minsize(360, 560)

        client = RemoteClient()

        tk.Label(win, text="🖥️ Control Another PC", fg="#eef1ec", bg="#0d0d0d",
                 font=("Arial", 14, "bold")).pack(pady=(16, 2))
        tk.Label(win, text="ওই PC-তেও Abu AI Desktop চালু ও Start Server করা থাকতে হবে।",
                 fg="#888", bg="#0d0d0d", font=("Arial", 8), wraplength=360).pack(pady=(0, 10))

        # ---- connect form ----
        conn_box = tk.LabelFrame(win, text=" Connect ", fg="#eee", bg="#141414",
                                  labelanchor="nw", bd=1, font=("Arial", 9, "bold"))
        conn_box.pack(fill="x", padx=16, pady=(0, 10))

        def _row(label, show=None, default=""):
            r = tk.Frame(conn_box, bg="#141414")
            r.pack(fill="x", padx=8, pady=4)
            tk.Label(r, text=label, fg="#aaa", bg="#141414", font=("Arial", 9), width=10, anchor="w").pack(side="left")
            e = tk.Entry(r, bg="#0e100d", fg="#eee", relief="flat", insertbackground="#eee", show=show)
            e.insert(0, default)
            e.pack(side="left", fill="x", expand=True, ipady=3)
            return e

        ip_entry = _row("PC IP", default="192.168.1.10")
        port_entry = _row("Port", default=str(srv.PORT))
        user_entry = _row("Username")
        pass_entry = _row("Password", show="*")

        status_row = tk.Frame(win, bg="#0d0d0d")
        status_row.pack(fill="x", padx=16, pady=(0, 4))
        status_label = tk.Label(status_row, text="🔴 Disconnected", fg="#c66", bg="#0d0d0d", font=("Arial", 10, "bold"))
        status_label.pack(side="left")
        pcname_label = tk.Label(win, text="", fg="#8fd18f", bg="#0d0d0d", font=("Arial", 9))
        pcname_label.pack(pady=(0, 6))

        btn_row = tk.Frame(win, bg="#0d0d0d")
        btn_row.pack(fill="x", padx=16, pady=(0, 10))
        connect_btn = tk.Button(btn_row, text="Connect", bg="#4CAF50", fg="#08130a",
                                 font=("Arial", 10, "bold"), relief="flat")
        connect_btn.pack(side="left", expand=True, fill="x", padx=(0, 4), ipady=5)
        disconnect_btn = tk.Button(btn_row, text="Disconnect", bg="#a33", fg="white",
                                    relief="flat", state="disabled")
        disconnect_btn.pack(side="left", expand=True, fill="x", padx=(4, 0), ipady=5)

        # ---- control panel (only usable once connected) ----
        pad_box = tk.LabelFrame(win, text=" Touchpad (drag to move mouse) ", fg="#eee", bg="#141414",
                                 labelanchor="nw", bd=1, font=("Arial", 9, "bold"))
        pad_box.pack(fill="x", padx=16, pady=(0, 10))
        pad = tk.Canvas(pad_box, bg="#0e100d", height=110, highlightthickness=0)
        pad.pack(fill="x", padx=8, pady=8)
        pad_state = {"x": 0, "y": 0}

        def pad_press(e):
            pad_state["x"], pad_state["y"] = e.x, e.y

        def pad_drag(e):
            if not client.connected:
                return
            dx, dy = e.x - pad_state["x"], e.y - pad_state["y"]
            pad_state["x"], pad_state["y"] = e.x, e.y
            client.move_relative(dx * 2.2, dy * 2.2)

        pad.bind("<Button-1>", pad_press)
        pad.bind("<B1-Motion>", pad_drag)

        click_row = tk.Frame(win, bg="#0d0d0d")
        click_row.pack(fill="x", padx=16, pady=(0, 6))
        tk.Button(click_row, text="Left Click", command=lambda: client.click("left"),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 3), ipady=4)
        tk.Button(click_row, text="Right Click", command=lambda: client.click("right"),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=3, ipady=4)
        tk.Button(click_row, text="Double Click", command=lambda: client.double_click("left"),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(3, 0), ipady=4)

        drag_row = tk.Frame(win, bg="#0d0d0d")
        drag_row.pack(fill="x", padx=16, pady=(0, 6))
        tk.Button(drag_row, text="🖱 Hold (drag) ⬇", command=lambda: client.mouse_down("left"),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 3), ipady=4)
        tk.Button(drag_row, text="🖱 Release ⬆", command=lambda: client.mouse_up("left"),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(3, 0), ipady=4)
        tk.Label(win, text="(Hold চেপে touchpad-এ drag করুন, শেষে Release চাপুন — ফাইল/আইকন সরাতে)",
                 fg="#666", bg="#0d0d0d", font=("Arial", 8), wraplength=360).pack()

        scroll_row = tk.Frame(win, bg="#0d0d0d")
        scroll_row.pack(fill="x", padx=16, pady=(8, 6))
        tk.Button(scroll_row, text="▲ Scroll Up", command=lambda: client.scroll(3),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(0, 3), ipady=4)
        tk.Button(scroll_row, text="▼ Scroll Down", command=lambda: client.scroll(-3),
                  bg="#2b2b2b", fg="#eee", relief="flat").pack(side="left", expand=True, fill="x", padx=(3, 0), ipady=4)

        type_row = tk.Frame(win, bg="#0d0d0d")
        type_row.pack(fill="x", padx=16, pady=(4, 6))
        type_entry = tk.Entry(type_row, bg="#141414", fg="#eee", relief="flat", insertbackground="#eee")
        type_entry.pack(side="left", fill="x", expand=True, ipady=4)

        def send_type():
            txt = type_entry.get()
            if txt:
                client.type_text(txt)
                type_entry.delete(0, tk.END)

        tk.Button(type_row, text="Type", command=send_type,
                  bg="#2196F3", fg="white", relief="flat").pack(side="left", padx=(4, 0), ipady=4)

        sc_row = tk.Frame(win, bg="#0d0d0d")
        sc_row.pack(fill="x", padx=16, pady=(0, 12))
        sc_entry = tk.Entry(sc_row, bg="#141414", fg="#eee", relief="flat", insertbackground="#eee")
        sc_entry.insert(0, "ctrl+c")
        sc_entry.pack(side="left", fill="x", expand=True, ipady=4)
        tk.Button(sc_row, text="Send Shortcut", command=lambda: client.send_shortcut(sc_entry.get()),
                  bg="#2196F3", fg="white", relief="flat").pack(side="left", padx=(4, 0), ipady=4)

        # ---- enable/disable control widgets based on connection state ----
        control_widgets = [pad, *click_row.winfo_children(), *drag_row.winfo_children(),
                            *scroll_row.winfo_children(), type_entry, sc_entry]

        def set_controls_enabled(enabled):
            state = "normal" if enabled else "disabled"
            for w in control_widgets:
                try:
                    w.config(state=state)
                except tk.TclError:
                    pass

        set_controls_enabled(False)

        def do_connect():
            connect_btn.config(state="disabled", text="Connecting...")

            def worker():
                ok, msg = client.connect(ip_entry.get(), port_entry.get(), user_entry.get(), pass_entry.get())

                def after():
                    connect_btn.config(text="Connect")
                    if ok:
                        status_label.config(text="🟢 Connected", fg="#4CAF50")
                        pcname_label.config(text=f"Connected PC: {client.pc_name}")
                        connect_btn.config(state="disabled")
                        disconnect_btn.config(state="normal")
                        set_controls_enabled(True)
                    else:
                        status_label.config(text="🔴 Disconnected", fg="#c66")
                        connect_btn.config(state="normal")
                        messagebox.showerror("Abu AI", msg)

                win.after(0, after)

            threading.Thread(target=worker, daemon=True).start()

        def do_disconnect():
            client.disconnect()
            status_label.config(text="🔴 Disconnected", fg="#c66")
            pcname_label.config(text="")
            connect_btn.config(state="normal")
            disconnect_btn.config(state="disabled")
            set_controls_enabled(False)

        connect_btn.config(command=do_connect)
        disconnect_btn.config(command=do_disconnect)

        def on_close():
            client.disconnect()
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", on_close)

    # ---------------- See Control (connected phones) ----------------
    def open_control_view(self):
        win = tk.Toplevel(self.root)
        win.title("See Control - কারা connect আছে")
        win.configure(bg="#0d0d0d")
        win.geometry("380x560")
        win.minsize(340, 420)

        tk.Label(win, text="👁 See Control", fg="#eef1ec", bg="#0d0d0d",
                 font=("Arial", 14, "bold")).pack(pady=(16, 2))
        tk.Label(win, text="কোন কোন ফোন এখন control করছে, তাদের নাম, ব্যাটারি ও স্ক্রিন",
                 fg="#888", bg="#0d0d0d", font=("Arial", 9)).pack(pady=(0, 10))

        container = tk.Frame(win, bg="#0d0d0d")
        container.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        slot_widgets = {}
        for slot in range(1, srv.MAX_CONTROLLERS + 1):
            f = tk.Frame(container, bg="#141414")
            f.pack(fill="x", pady=6, ipady=8, ipadx=8)
            tk.Label(f, text=f"Controller {slot}", fg="#eee", bg="#141414",
                     font=("Arial", 10, "bold")).pack(anchor="w", padx=10, pady=(6, 0))
            info_lbl = tk.Label(f, text="⭘ সংযুক্ত নেই (not connected)", fg="#888", bg="#141414",
                                 font=("Arial", 9), justify="left")
            info_lbl.pack(anchor="w", padx=10, pady=(2, 6))
            img_lbl = tk.Label(f, bg="#0a0a0a", text="", fg="#555")
            img_lbl.pack(padx=10, pady=(0, 8))
            slot_widgets[slot] = {"info": info_lbl, "img": img_lbl, "photo": None}

        def refresh():
            if not win.winfo_exists():
                return
            for slot, widgets in slot_widgets.items():
                connected = slot in srv.controllers
                info = srv.phone_info.get(slot, {})
                nickname = info.get("nickname") or f"Phone {slot}"
                battery = info.get("battery")
                battery_txt = f"{round(battery)}%" if battery is not None else "—"

                if connected:
                    widgets["info"].config(
                        text=f"✅ সংযুক্ত | নাম: {nickname} | ব্যাটারি: {battery_txt}",
                        fg="#8fd18f")
                else:
                    widgets["info"].config(text="⭘ সংযুক্ত নেই (not connected)", fg="#888")

                frame_entry = srv.phone_screens.get(slot) if connected else None
                if frame_entry:
                    try:
                        img = Image.open(io.BytesIO(frame_entry["jpeg"]))
                        img.thumbnail((260, 150))
                        photo = ImageTk.PhotoImage(img)
                        widgets["img"].config(image=photo, text="")
                        widgets["photo"] = photo  # keep a reference so it isn't garbage-collected
                    except Exception:
                        widgets["img"].config(image="", text="স্ক্রিন পাওয়া যাচ্ছে না")
                        widgets["photo"] = None
                else:
                    widgets["img"].config(image="", text="স্ক্রিন শেয়ার করছে না" if connected else "")
                    widgets["photo"] = None
            win.after(1000, refresh)

        refresh()

    # ---------------- log ----------------
    def poll_log(self):
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", tk.END)
        for line in reversed(list(srv.activity_log)):
            self.log_text.insert(tk.END, line + "\n")
        self.log_text.config(state="disabled")
        self.root.after(2000, self.poll_log)

    def on_close(self):
        if self.server_thread:
            try:
                self.server_thread.shutdown()
            except Exception:
                pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    AbuAILauncher(root)
    root.mainloop()
