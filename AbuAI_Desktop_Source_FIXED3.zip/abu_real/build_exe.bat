@echo off
REM ============================================================
REM  Builds "Abu AI Desktop.exe" - a double-click app, no Python
REM  needed on this PC afterwards. Run this ONCE (needs Python
REM  installed just for this step).
REM ============================================================

cd /d "%~dp0"

echo Installing required packages...
pip install flask mss pillow pyautogui pyinstaller requests

echo.
echo Building Abu AI Desktop.exe (this can take a minute)...
pyinstaller --onefile --noconsole --name "Abu AI Desktop" --icon "abu_ai_icon.ico" --add-data "abu_ai_icon.ico;." abu_ai_launcher.py

echo.
echo Done! Your app is at:  dist\Abu AI Desktop.exe
echo Copy that .exe into its own folder (along with abu_apps.json if you
echo want to keep your custom app list) and double-click it any time.
pause
